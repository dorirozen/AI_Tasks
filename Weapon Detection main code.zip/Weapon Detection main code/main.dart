import 'package:device_preview/device_preview.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:guardian_view/core/common/app/providers/user_provider.dart';
import 'package:guardian_view/core/helpers/bloc_observer.dart';
import 'package:guardian_view/core/services/getit/injection_container.main.dart';
import 'package:guardian_view/core/services/router/app_router.dart';
import 'package:guardian_view/core/services/router/router_observer.dart';
import 'package:guardian_view/src/admin_cruds/data/data_sources/cruds_for_settings.dart/admin_remote_settings_cruds.dart';
import 'package:guardian_view/src/dashboard/providers/dash_controller.dart';
import 'package:provider/provider.dart';
import 'core/common/app/providers/settings_provider.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await initInjection();
  Bloc.observer = AppBlocObserver();
  runApp(
    DevicePreview(
      enabled: true,
      builder: (context) => const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget with WidgetsBindingObserver {
  const MyApp({
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(500.0, 730.4),
      minTextAdapt: true,
      splitScreenMode: true,
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) => DashBoardController(),
          ),
          ChangeNotifierProvider(
            create: (_) => UserProvider(),
          ),
          ChangeNotifierProvider(
              create: (_) => SettingsProvider(sl<CrudSettingDataSource>())),
        ],
        child: MaterialApp(
          navigatorObservers: [sl<MyNavigatorObserver>()],
          builder: DevicePreview.appBuilder,
          title: 'Guardian View App',
          debugShowCheckedModeBanner: false,
          initialRoute: '/',
          onGenerateRoute: onGenerateRoute,
        ),
      ),
    );
  }
}
