enum BasicDialogStatus { success, error, warning }

enum DialogType { basic }
