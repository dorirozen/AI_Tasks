enum UpdateSettingsAction { threshHold, isLive }
