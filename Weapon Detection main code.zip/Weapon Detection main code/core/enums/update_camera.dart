enum UpdateCameraAction {
  locationName,
  latitude,
  landscape,
}
