enum UpdateUserAction { displayName, email, password, city, phoneNum, onDuty }

enum EditUserActionAdmin {
  displayName,
  email,
  city,
  phoneNum,
}
