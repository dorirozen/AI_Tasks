import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/core/common/dialog/dialog_manager.dart';
import 'package:guardian_view/core/common/views/page_un_implemented.dart';
import 'package:guardian_view/core/extentions/context_extensions.dart';
import 'package:guardian_view/core/services/getit/injection_container.main.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_bloc.dart';
import 'package:guardian_view/src/auth/presention/views/sign_in_screen.dart';
import 'package:guardian_view/src/auth/presention/views/sign_up_screen.dart';
import 'package:guardian_view/src/on_boarding/data/datasources/on_boarding_local_data_source.dart';
import 'package:guardian_view/src/on_boarding/presention/cubit/on_boarding_cubit.dart';
import 'package:guardian_view/src/on_boarding/presention/screens/on_boarding_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../src/admin_cruds/presention/blocs/settings_bloc/settings_bloc.dart';
import '../../../src/dashboard/views/dash_board.dart';
import '../../../src/connection/logic/cubit/internet_cubit.dart';
import '../../../src/video/presention/cubit/post_upload_cubit.dart';
import '../../../src/video/presention/cubit/video_cubit.dart';
import '../../../src/video/presention/views/video_adding.dart';
// import '../../../src/profile_try/ui.dart';

Route<dynamic> onGenerateRoute(RouteSettings settings) {
  switch (settings.name) {
    case '/':
      final pref = sl<SharedPreferences>();
      return _pageBuilder(
        (context) {
          if (pref.getBool(kFirstTimerKey) ?? true) {
            return BlocProvider(
              create: (_) => sl<OnBoardingCubit>(),
              child: const OnBoardingScreen(),
            );
          } else if (sl<FirebaseAuth>().currentUser != null) {
            // pushing the user into the dashboard and we need his info
            final user = sl<FirebaseAuth>().currentUser!;
            context.userProvider.initUserFromFirebase(user);
            MultiBlocProvider(providers: [
              BlocProvider(create: (_) => sl<InternetCubit>()),
              BlocProvider(create: (_) => sl<SettingsBloc>()),
            ], child: const DashBoardScreen());

            // return BlocProvider(
            //     create: (_) => sl<InternetCubit>(),
            //     child: const DashBoardScreen());
          }

          return BlocProvider(
            create: (_) => sl<AuthBloc>(),
            child: const SignInScreen(),
          );
        },
        settings: settings,
      );
    case SignInScreen.routeName:
      return _pageBuilder(
          (_) => BlocProvider(
                create: (_) => sl<AuthBloc>(),
                child: const SignInScreen(),
              ),
          settings: settings);
    case SignUpScreen.routeName:
      return _pageBuilder(
          (_) => BlocProvider(
                create: (_) => sl<AuthBloc>(),
                child: const SignUpScreen(),
              ),
          settings: settings);
    case DashBoardScreen.routeName:
      return _pageBuilder(
          (_) => BlocProvider(
              create: (_) => sl<InternetCubit>(),
              child: const DashBoardScreen()),
          settings: settings);
    case UploadVideo.routeName:
      return _pageBuilder(
        (_) => MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (_) => sl<VideoCubit>(),
            ),
            BlocProvider(
              create: (_) => sl<PostUploadCubit>(),
            ),
          ],
          child: const UploadVideo(),
        ),
        settings: settings,
      );
    //   return _pageBuilder(
    //       (_) => BlocProvider(
    //             create: (_) => sl<VideoCubit>(),
    //             child: const UploadVideo(),
    //           ),
    //       settings: settings);
    // case PageUnImplemented.routeName:
    //   return _pageBuilder(
    //     (_) => const PageUnImplemented(),
    //     settings: settings,
    //   );
    //normal approach
    /*
    case "OnBoardingScreen.routeName":
      return MaterialPageRoute(
        builder: (_) => BlocProvider(
          create: (_) => sl<OnBoardingCubit>(),
          child: const OnBoardingScreen(),
        ),
      );
     */

    /*
    case '/':
      return _pageBuilder(
          (_) => HomeScreen(
                title: "Home Screen",
                color: Colors.blueAccent,
              ),
          settings: settings);
     */
    default:
      return _pageBuilder(
        (_) => const PageUnImplemented(txt: 'Default Page'),
        settings: settings,
      );
  }
}

///
PageRouteBuilder<dynamic> _pageBuilder(
    Widget Function(BuildContext context) page,
    {required RouteSettings settings}) {
  return PageRouteBuilder(
      settings: settings,
      transitionsBuilder: (_, animation, __, child) => FadeTransition(
            opacity: animation,
            child: child,
          ),
      pageBuilder: (context, _, __) => DialogManager(child: page(context)));
}
