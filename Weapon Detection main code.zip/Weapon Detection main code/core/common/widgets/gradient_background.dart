import 'package:flutter/material.dart';
import 'package:guardian_view/core/common/app/providers/settings_provider.dart';
import 'package:provider/provider.dart';

import '../../../src/admin_cruds/presention/settings_pages/widgets/iconLive.dart';

class GradientBackGround extends StatelessWidget {
  const GradientBackGround({
    Key? key,
    required this.image,
    required this.child,
    this.toUse,
    this.darkenImage = false,
    this.imageSize,
    this.needIconIsLive,
  }) : super(key: key);
  final bool? needIconIsLive;
  final Widget child;
  final String image;
  final bool? toUse;
  final bool darkenImage;
  final Size? imageSize;

  @override
  Widget build(BuildContext context) {
    final theBool =
        context.watch<SettingsProvider>().isLive == 'true' ? true : false;
    return toUse == null || toUse == true
        ? Stack(
            children: [
              Container(
                constraints: const BoxConstraints.expand(),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(image),
                    fit: BoxFit.cover,
                    colorFilter: darkenImage
                        ? ColorFilter.mode(
                            Colors.black.withOpacity(0.7),
                            BlendMode.darken,
                          )
                        : null,
                  ),
                ),
              ),
              if (imageSize != null)
                Align(
                  heightFactor: imageSize!.height,
                  widthFactor: imageSize!.width,
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    height: imageSize!.height,
                    width: imageSize!.width,
                    child: Container(
                      width: imageSize!.width,
                      height: imageSize!.height,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(image),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ),
              child,
              if (needIconIsLive ?? false)
                Positioned(
                  top: 40,
                  left: 20,
                  child: buildLiveStatusIcon(theBool),
                ),
            ],
          )
        : child;
  }
}

/*
class GradientBackGround extends StatelessWidget {
  const GradientBackGround({
    Key? key,
    required this.image,
    required this.child,
    this.toUse,
    this.darkenImage = false,
    this.imageSize,
    this.needIconIsLive,
  }) : super(key: key);
  final bool? needIconIsLive;
  final Widget child;
  final String image;
  final bool? toUse;
  final bool darkenImage;
  final Size? imageSize;

  @override
  Widget build(BuildContext context) {
    final theBool =
        context.read<SettingsProvider>().isLive == 'true' ? true : false;
    return toUse == null || toUse == true
        ? Stack(
            children: [
              Positioned(
                  top: 40, left: 20, child: buildLiveStatusIcon(theBool)),
              Container(
                constraints: const BoxConstraints.expand(),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(image),
                    fit: BoxFit.cover,
                    colorFilter: darkenImage
                        ? ColorFilter.mode(
                            Colors.black.withOpacity(0.7),
                            BlendMode.darken,
                          )
                        : null,
                  ),
                ),
              ),
              if (imageSize != null)
                Align(
                  heightFactor: imageSize!.height,
                  widthFactor: imageSize!.width,
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    height: imageSize!.height,
                    width: imageSize!.width,
                    child: Container(
                      width: imageSize!.width,
                      height: imageSize!.height,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(image),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ),
              child,
            ],
          )
        : child;
  }
}
*/
// import 'package:flutter/material.dart';
//
// class GradientBackGround extends StatelessWidget {
//   const GradientBackGround(
//       {Key? key, required this.image, required this.child, this.toUse})
//       : super(key: key);
//   final Widget child;
//   final String image;
//   final bool? toUse;
//
//   @override
//   Widget build(BuildContext context) {
//     return toUse == null || toUse == true
//         ? Container(
//             constraints: const BoxConstraints.expand(),
//             decoration: BoxDecoration(
//               image: DecorationImage(
//                 image: AssetImage(image),
//                 fit: BoxFit.cover,
//               ),
//             ),
//             child: child)
//         : child;
//   }
// }
