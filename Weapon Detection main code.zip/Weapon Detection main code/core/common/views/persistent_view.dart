import 'package:flutter/material.dart';
import 'package:guardian_view/core/common/app/providers/tab_navigator.dart';
import 'package:provider/provider.dart';

class PersistentView extends StatefulWidget {
  const PersistentView({super.key, this.body});
  final Widget? body;
  @override
  State<PersistentView> createState() => _PersistentViewState();
}

class _PersistentViewState extends State<PersistentView>
    with AutomaticKeepAliveClientMixin {
  @override
  Widget build(BuildContext context) {
    super.build(context);
    // context.watch<TabNavigator>() = go up the widget tree , find me the closest tabNavigator
    return widget.body ?? context.watch<TabNavigator>().currentPage.child;
  }

  @override
  bool get wantKeepAlive => true;
}
// import 'package:flutter_bloc/flutter_bloc.dart';
//
// import '../../../src/admin_cruds/presention/blocs/settings_bloc/settings_bloc.dart';
// import '../../../src/admin_cruds/presention/blocs/settings_bloc/settings_state.dart';
//
// class PersistentView extends StatefulWidget {
//   const PersistentView({super.key, this.body});
//   final Widget? body;
//   @override
//   State<PersistentView> createState() => _PersistentViewState();
// }
//
// class _PersistentViewState extends State<PersistentView>
//     with AutomaticKeepAliveClientMixin {
//   @override
//   Widget build(BuildContext context) {
//     super.build(context);
//     return Stack(
//       children: [
//         widget.body ?? context.watch<TabNavigator>().currentPage.child,
//         Positioned(
//           top: 40, // Adjust this value to position the icon as needed
//           right: 20, // Adjust this value to position the icon as needed
//           child: BlocBuilder<SettingsBloc, SettingsState>(
//             builder: (context, state) {
//               if (state is SettingsStateGet) {
//                 return Container(
//                   padding: EdgeInsets.all(8),
//                   color: Colors.yellow, // This will make it easier to spot
//                   child: Icon(
//                     state.settingCrud.isLive
//                         ? Icons.online_prediction
//                         : Icons.offline_bolt,
//                     color: state.settingCrud.isLive ? Colors.green : Colors.red,
//                     size: 50,
//                   ),
//                 );
//               }
//               return const SizedBox
//                   .shrink(); // Return an empty widget if state is not SettingsStateGet
//             },
//           ),
//         ),
//       ],
//     );
//   }
//
//   @override
//   bool get wantKeepAlive => true;
// }
