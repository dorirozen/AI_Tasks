import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:guardian_view/core/services/getit/injection_container.main.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/auth/data/models/user_model.dart';

class UserProvider extends ChangeNotifier {
  LocalUserModel? _user;
  LocalUserModel? get user => _user;

  void initUserFromFirebase(User user) {
    final localUser = const LocalUserModel.empty().copyWith(
      uid: user.uid,
      email: user.email,
      fullName: user.displayName,
    );
    initUser(localUser);
  }

  void initUser(LocalUserModel? user) {
    if (_user != user) {
      _user = user;
      if (user != null) {
        _fetchAndUpdateUserData(user);
        // debugPrint(user.toString());
      }
    }
  }

  set user(LocalUserModel? user) {
    if (_user != user) {
      _fetchAndUpdateUserData(user!);
    }
  }

  Future<void> _fetchAndUpdateUserData(LocalUserModel? user) async {
    try {
      DocumentReference<DataMap> dataRef = sl<FirebaseFirestore>()
          .collection('users') // Replace with your collection name
          .doc(user!.uid);
      DocumentSnapshot userSnapshot = await dataRef.get();
      if (userSnapshot.exists) {
        DataMap userData = userSnapshot.data() as DataMap;

        LocalUserModel updatedUser = user.copyWith(
          city: userData['city'],
          phoneNum: userData['phoneNum'],
          latitude: userData['latitude'],
          longitude: userData['longitude'],
        );
        _user = updatedUser;
        // Future.delayed(Duration.zero, notifyListeners);
        notifyListeners();
      } else {
        debugPrint('User data not found in Firestore.');
      }
    } catch (error) {
      debugPrint('Error fetching user data from Firestore: $error');
    }
  }

  Future<void> signOut() async {
    try {
      await FirebaseAuth.instance.signOut();
      _user = null;
      notifyListeners();
      debugPrint('\nSigned out !\n');
    } catch (error) {
      debugPrint('Error signing out: $error');
    }
  }
}
