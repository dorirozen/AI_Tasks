import 'package:flutter/foundation.dart';

import '../../../../src/admin_cruds/data/data_sources/cruds_for_settings.dart/admin_remote_settings_cruds.dart';
import '../../../../src/admin_cruds/domain/entities/setting.dart';

class SettingsProvider extends ChangeNotifier {
  String _isLive = 'false';
  final CrudSettingDataSource _dataSource;
  SettingsProvider(this._dataSource) {
    initializeSettings();
  }
  String get isLive => _isLive;

  void setIsLive(String value) {
    _isLive = value;
    notifyListeners();
  }

  Future<void> initializeSettings() async {
    try {
      SettingCrud? settings = await _dataSource.getSetting();
      final theBool = settings.isLive == true ? 'true' : 'false';
      setIsLive(theBool);
      notifyListeners();
    } catch (e) {
      debugPrint('Error initializing settings: $e');
    }
  }
}
