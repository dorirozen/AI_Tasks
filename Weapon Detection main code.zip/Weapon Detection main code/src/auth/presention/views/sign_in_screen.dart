import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/core/common/app/providers/user_provider.dart';
import 'package:guardian_view/core/common/widgets/rounded_button.dart';
import 'package:guardian_view/core/resources/colors.dart';
import 'package:guardian_view/core/resources/fonts.dart';
import 'package:guardian_view/core/utils/core_utils.dart';
import 'package:guardian_view/src/auth/data/models/user_model.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_bloc.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_event.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_state.dart';
import 'package:guardian_view/src/auth/presention/widgets/sign_in_form.dart';
import 'package:guardian_view/src/dashboard/views/dash_board.dart';
import '../../../../core/services/getit/injection_container.main.dart';
import '../../../video/presention/views/video_adding.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({Key? key}) : super(key: key);

  static const routeName = '/sign-in';

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen>
    with TickerProviderStateMixin {
  late Animation<double> _animation;
  late AnimationController _animationController;

  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    _animationController =
        AnimationController(vsync: this, duration: const Duration(seconds: 20));
    _animation =
        CurvedAnimation(parent: _animationController, curve: Curves.linear)
          ..addListener(() {
            setState(() {});
          })
          ..addStatusListener((animationStatus) {
            if (animationStatus == AnimationStatus.completed) {
              _animationController.reset();
              _animationController.forward();
            }
          });
    _animationController.forward();
    super.initState();
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is AuthStateError) {
            CoreUtils.showSnackBar(context, state.message);
          } else if (state is AuthStateSignedIn) {
            context.read<UserProvider>().initUser(state.user as LocalUserModel);
            debugPrint('from sign in');
            if (sl<FirebaseAuth>().currentUser!.email != 'edit@g.com') {
              Navigator.pushReplacementNamed(
                  context, DashBoardScreen.routeName);
            } else {
              Navigator.pushReplacementNamed(context, UploadVideo.routeName);
            }
          }
        },
        builder: (context, state) {
          return Stack(
            children: [
              ColorFiltered(
                colorFilter: ColorFilter.mode(
                    Colors.black.withOpacity(0.9), BlendMode.darken),
                child: Image.asset(
                  'assets/images/concealed weapons detection.png',
                  fit: BoxFit.cover,
                  width: double.infinity,
                  height: double.infinity,
                  alignment: FractionalOffset(_animation.value, 0),
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                              width: 300,
                              child: Text(
                                'Guardian View',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: Fonts.beautiful_people,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 32,
                                  shadows: [
                                    Shadow(
                                      offset: Offset(0, 3),
                                      blurRadius: 5,
                                      color: Colors.black54,
                                    ),
                                  ],
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            const SizedBox(width: 6),
                            SizedBox(
                              child: Image.asset(
                                'assets/images/projectLogo.png',
                                fit: BoxFit.contain,
                                width: 50,
                                height: 50,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Expanded(child: SizedBox()), // Flexible space
                      Center(
                        child: SizedBox(
                          width: 300,
                          child: Column(
                            children: [
                              SignInForm(
                                emailController: emailController,
                                passwordController: passwordController,
                                formKey: formKey,
                              ),
                              const SizedBox(height: 20),
                              if (state is AuthStateLoading)
                                const Center(child: CircularProgressIndicator())
                              else
                                RoundedButton(
                                  label: 'Sign In',
                                  buttonColor: MyColors.primaryColor,
                                  labelColor: Colors.white,
                                  onPressed: () {
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();
                                    FirebaseAuth.instance.currentUser?.reload();
                                    if (formKey.currentState!.validate()) {
                                      context.read<AuthBloc>().add(
                                            AuthEventSignIn(
                                              email:
                                                  emailController.text.trim(),
                                              password: passwordController.text
                                                  .trim(),
                                            ),
                                          );
                                    }
                                  },
                                ),
                            ],
                          ),
                        ),
                      ),
                      const Expanded(child: SizedBox()), // Flexible space
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/*
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/core/common/app/providers/user_provider.dart';
import 'package:guardian_view/core/common/widgets/gradient_background.dart';
import 'package:guardian_view/core/common/widgets/rounded_button.dart';
import 'package:guardian_view/core/resources/colors.dart';
import 'package:guardian_view/core/resources/fonts.dart';
import 'package:guardian_view/core/resources/media_res.dart';
import 'package:guardian_view/core/utils/core_utils.dart';
import 'package:guardian_view/src/auth/data/models/user_model.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_bloc.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_event.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_state.dart';
import 'package:guardian_view/src/auth/presention/views/sign_up_screen.dart';
import 'package:guardian_view/src/auth/presention/widgets/sign_in_form.dart';
import 'package:guardian_view/src/dashboard/views/dash_board.dart';

import '../../../../core/services/getit/injection_container.main.dart';
import '../../../video/presention/views/video_adding.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({Key? key}) : super(key: key);

  static const routeName = '/sign-in';
  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen>
    with TickerProviderStateMixin {
  // new
  late Animation<double> _animation;
  late AnimationController _animationController;

  ///
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    _animationController =
        AnimationController(vsync: this, duration: const Duration(seconds: 20));
    _animation =
        CurvedAnimation(parent: _animationController, curve: Curves.linear)
          ..addListener(() {
            setState(() {});
          })
          ..addStatusListener((animationStatus) {
            if (animationStatus == AnimationStatus.completed) {
              _animationController.reset();
              _animationController.forward();
            }
          });
    _animationController.forward();
    super.initState();
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();

    // new
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is AuthStateError) {
            CoreUtils.showSnackBar(context, state.message);
          } else if (state is AuthStateSignedIn) {
            context.read<UserProvider>().initUser(state.user as LocalUserModel);
            debugPrint('from sign in');
            if (sl<FirebaseAuth>().currentUser!.email != 'edit@g.com') {
              Navigator.pushReplacementNamed(
                  context, DashBoardScreen.routeName);
            } else {
              Navigator.pushReplacementNamed(context, UploadVideo.routeName);
            }
          }
        },
        builder: (context, state) {
          return Stack(
            children: [
              Image.asset(
                'assets/images/concealed weapons detection.png',
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
                alignment: FractionalOffset(_animation.value, 0),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Easy to learn, discover more skills.',
                        style: TextStyle(
                          fontFamily: Fonts.beautiful_people,
                          fontWeight: FontWeight.w700,
                          fontSize: 32,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Sign In to your account',
                        style: TextStyle(
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 10),
                      SignInForm(
                        emailController: emailController,
                        passwordController: passwordController,
                        formKey: formKey,
                      ),
                      const SizedBox(height: 10),
                      if (state is AuthStateLoading)
                        const Center(child: CircularProgressIndicator())
                      else
                        RoundedButton(
                          label: 'Sign In',
                          buttonColor: MyColors.primaryColor,
                          labelColor: Colors.white,
                          onPressed: () {
                            FocusManager.instance.primaryFocus?.unfocus();
                            FirebaseAuth.instance.currentUser?.reload();
                            if (formKey.currentState!.validate()) {
                              context.read<AuthBloc>().add(
                                    AuthEventSignIn(
                                      email: emailController.text.trim(),
                                      password: passwordController.text.trim(),
                                    ),
                                  );
                            }
                          },
                        ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
*/
/*


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: BlocConsumer<AuthBloc, AuthState>(
      listener: (_, state) {
        if (state is AuthStateError) {
          CoreUtils.showSnackBar(context, state.message);
        } else if (state is AuthStateSignedIn) {
          context.read<UserProvider>().initUser(state.user as LocalUserModel);
          debugPrint('from sign in');
          if (sl<FirebaseAuth>().currentUser!.email != 'edit@g.com') {
            Navigator.pushReplacementNamed(context, DashBoardScreen.routeName);
          } else {
            Navigator.pushReplacementNamed(context, UploadVideo.routeName);
          }
        }
      },
      //concealed weapons detection.png
      builder: (context, state) {
        return Stack(
          children: [
            Image.asset(
              'assets/images/concealed weapons detection.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
              alignment: FractionalOffset(_animation.value, 0),
            ),
            const Text(
              'Easy to learn, discover more skills.',
              style: TextStyle(
                fontFamily: Fonts.beautiful_people,
                fontWeight: FontWeight.w700,
                fontSize: 32,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'sign In to your account',
                  style: TextStyle(
                    fontSize: 14,
                  ),
                ),
                // Baseline(
                //   baseline: 100,
                //   baselineType: TextBaseline.alphabetic,
                //   child: TextButton(
                //     onPressed: () {
                //       Navigator.pushReplacementNamed(
                //         context,
                //         SignUpScreen.routeName,
                //       );
                //     },
                //     child: const Text('Register account ?'),
                //   ),
                // ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            SignInForm(
                emailController: emailController,
                passwordController: passwordController,
                formKey: formKey),
            const SizedBox(
              height: 10,
            ),
            state is AuthStateLoading
                ? const Center(child: CircularProgressIndicator())
                : RoundedButton(
                    label: 'Sign In',
                    buttonColor: MyColors.primaryColor,
                    labelColor: Colors.white,
                    onPressed: () {
                      FocusManager.instance.primaryFocus?.unfocus();
                      FirebaseAuth.instance.currentUser?.reload();
                      if (formKey.currentState!.validate()) {
                        context.read<AuthBloc>().add(
                              AuthEventSignIn(
                                email: emailController.text.trim(),
                                password: passwordController.text.trim(),
                              ),
                            );
                      }
                    },
                  ),
          ],
        );
      },
    ));
  }
}
*/
/*
builder: (context, state) {
          return GradientBackGround(
              image: MediaRes.image3,
              child: SafeArea(
                child: Center(
                  child: ListView(
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    children: [
                      const Text(
                        'Easy to learn, discover more skills.',
                        style: TextStyle(
                          fontFamily: Fonts.beautiful_people,
                          fontWeight: FontWeight.w700,
                          fontSize: 32,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'sign In to your account',
                            style: TextStyle(
                              fontSize: 14,
                            ),
                          ),
                          // Baseline(
                          //   baseline: 100,
                          //   baselineType: TextBaseline.alphabetic,
                          //   child: TextButton(
                          //     onPressed: () {
                          //       Navigator.pushReplacementNamed(
                          //         context,
                          //         SignUpScreen.routeName,
                          //       );
                          //     },
                          //     child: const Text('Register account ?'),
                          //   ),
                          // ),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      SignInForm(
                          emailController: emailController,
                          passwordController: passwordController,
                          formKey: formKey),
                      const SizedBox(
                        height: 10,
                      ),
                      state is AuthStateLoading
                          ? const Center(child: CircularProgressIndicator())
                          : RoundedButton(
                              label: 'Sign In',
                              buttonColor: MyColors.primaryColor,
                              labelColor: Colors.white,
                              onPressed: () {
                                FocusManager.instance.primaryFocus?.unfocus();
                                FirebaseAuth.instance.currentUser?.reload();
                                if (formKey.currentState!.validate()) {
                                  context.read<AuthBloc>().add(
                                        AuthEventSignIn(
                                          email: emailController.text.trim(),
                                          password:
                                              passwordController.text.trim(),
                                        ),
                                      );
                                }
                              },
                            ),
                    ],
                  ),
                ),
              ));
        },
      ),
    );
  }
}
*/
