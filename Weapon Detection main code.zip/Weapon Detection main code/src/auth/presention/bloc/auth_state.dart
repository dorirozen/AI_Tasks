import 'package:equatable/equatable.dart';
import 'package:guardian_view/src/auth/domain/entites/local_user.dart';

abstract class AuthState extends Equatable {
  const AuthState();
  @override
  List<Object?> get props => [];
}

//basic helpers
class AuthStateInitial extends AuthState {
  const AuthStateInitial();
}

class AuthStateLoading extends AuthState {
  const AuthStateLoading();
}

class AuthStateError extends AuthState {
  const AuthStateError(this.message);
  final String message;
  @override
  List<String> get props => [message];
}

// basic return finished states
class AuthStateSignedIn extends AuthState {
  const AuthStateSignedIn(this.user);
  final LocalUser user;
  @override
  List<Object> get props => [user];
}

class AuthStateSignedUp extends AuthState {
  const AuthStateSignedUp();
}

class AuthStateUpdateUser extends AuthState {
  const AuthStateUpdateUser();
}

class AuthStateEditedUser extends AuthState {
  const AuthStateEditedUser();
}

class AuthStateGetUsers extends AuthState {
  const AuthStateGetUsers(this.users);
  final List<LocalUser> users;
  @override
  List<Object> get props => [users];
}
