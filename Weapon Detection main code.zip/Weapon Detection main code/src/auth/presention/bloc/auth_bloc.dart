import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/src/auth/domain/usecases/getUserActiveList.dart';
import 'package:guardian_view/src/auth/domain/usecases/signInUS.dart';
import 'package:guardian_view/src/auth/domain/usecases/signUpUS.dart';
import 'package:guardian_view/src/auth/domain/usecases/updateUserUS.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_event.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_state.dart';

import '../../domain/usecases/editUserAdminUS.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc({
    required SignInUS signIn,
    required SignUpUS signUp,
    required UpdateUserUS updateUser,
    required EditUserAdminUS editUserAdmin,
    required GetUserActiveListUS getUserActiveListUS,
  })  : _signIn = signIn,
        _signUp = signUp,
        _editUserAdmin = editUserAdmin,
        _updateUser = updateUser,
        _getUserActiveListUS = getUserActiveListUS,
        super(const AuthStateInitial()) {
    on<AuthEvent>((event, emit) {
      emit(const AuthStateLoading());
    });
    on<AuthEventSignIn>(_activateAuthEventSignIn);
    on<AuthEventSignUp>(_activateAuthEventSignUp);
    on<AuthEventUpdateUser>(_activateAuthEventUpdateUser);
    on<AuthEventEditUser>(_activateAuthEventEditUser);
    on<AuthEventGetUsers>(_activateAuthEventGetUsers);
  }
  final SignInUS _signIn;
  final SignUpUS _signUp;
  final UpdateUserUS _updateUser;
  final EditUserAdminUS _editUserAdmin;
  final GetUserActiveListUS _getUserActiveListUS;

  FutureOr<void> _activateAuthEventSignIn(
      AuthEventSignIn event, Emitter<AuthState> emit) async {
    final res = await _signIn(
      SignInParams(
        email: event.email,
        password: event.password,
      ),
    );
    res.fold(
      (failure) => emit(AuthStateError(failure.errorMessage)),
      (user) => emit(AuthStateSignedIn(user)),
    );
  }

  FutureOr<void> _activateAuthEventSignUp(
      AuthEventSignUp event, Emitter<AuthState> emit) async {
    final res = await _signUp(SignUpParams(
        email: event.email,
        fullName: event.name,
        phoneNum: event.phoneNum,
        city: event.city,
        password: event.password));
    res.fold(
      (l) => emit(AuthStateError(l.errorMessage)),
      (_) => emit(const AuthStateSignedUp()),
    );
  }

  FutureOr<void> _activateAuthEventEditUser(
      AuthEventEditUser event, Emitter<AuthState> emit) async {
    final res = await _editUserAdmin(EditUserParams(
        action: event.action, userData: event.userData, user: event.user));
    res.fold(
      (l) => emit(AuthStateError(l.errorMessage)),
      (_) => emit(const AuthStateEditedUser()),
    );
  }

  FutureOr<void> _activateAuthEventUpdateUser(
      AuthEventUpdateUser event, Emitter<AuthState> emit) async {
    final res = await _updateUser(
        UpdateUserParams(action: event.action, userData: event.userData));
    res.fold(
      (l) => emit(AuthStateError(l.errorMessage)),
      (_) => emit(const AuthStateUpdateUser()),
    );
  }

  FutureOr<void> _activateAuthEventGetUsers(
      AuthEventGetUsers event, Emitter<AuthState> emit) async {
    final res = await _getUserActiveListUS();
    res.fold((l) => emit(AuthStateError(l.errorMessage)), (r) {
      final filteredUsers =
          r.where((user) => user.email != event.currentUser.email).toList();
      emit(AuthStateGetUsers(filteredUsers));
      // emit(AuthStateGetUsers(r));
    });
  }
}
