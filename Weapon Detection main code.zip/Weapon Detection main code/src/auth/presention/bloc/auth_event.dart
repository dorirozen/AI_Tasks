import 'dart:io';
import 'package:equatable/equatable.dart';
import 'package:guardian_view/core/enums/update_user.dart';
import 'package:guardian_view/src/auth/domain/entites/local_user.dart';

abstract class AuthEvent extends Equatable {
  const AuthEvent();
  @override
  List<Object?> get props => [];
}

class AuthEventSignIn extends AuthEvent {
  const AuthEventSignIn({required this.email, required this.password});
  final String email;
  final String password;

  @override
  List<Object?> get props => [email, password];
}

class AuthEventGetUsers extends AuthEvent {
  final LocalUser currentUser;
  const AuthEventGetUsers({required this.currentUser});
}

class AuthEventSignUp extends AuthEvent {
  const AuthEventSignUp(
      {required this.email,
      required this.name,
      required this.phoneNum,
      required this.city,
      required this.password});
  final String email;
  final String name;
  final String city;
  final String phoneNum;
  final String password;

  @override
  List<Object?> get props => [email, name, password];
}

class AuthEventUpdateUser extends AuthEvent {
  AuthEventUpdateUser({required this.userData, required this.action})
      : assert(
            userData is String || userData is File,
            'userData have to be [String] or [File]'
            'but given ${userData.runtimeType.toString()}');
  final dynamic userData;
  final UpdateUserAction action;
  @override
  List<Object?> get props => [userData, action];
}

class AuthEventEditUser extends AuthEvent {
  AuthEventEditUser(
      {required this.userData, required this.action, required this.user})
      : assert(
            userData is String || userData is File,
            'userData have to be [String] or [File]'
            'but given ${userData.runtimeType.toString()}');
  final dynamic userData;
  final EditUserActionAdmin action;
  final LocalUser user;
  @override
  List<Object?> get props => [userData, action, user];
}
