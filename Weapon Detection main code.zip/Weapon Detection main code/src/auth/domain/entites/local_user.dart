import 'package:equatable/equatable.dart';

// TODO: needs to add - currectLocation
class LocalUser extends Equatable {
  const LocalUser(
      {required this.uid,
      required this.fullName,
      required this.email,
      required this.phoneNum,
      required this.city,
      this.latitude,
      this.longitude});
  // latitude and longitude
  final String uid;
  final String fullName;
  final String email;
  final String phoneNum;
  final String city;
  final double? latitude;
  final double? longitude;
  bool get isAdmin => email == 'd@g.com';
  const LocalUser.empty()
      : this(
          uid: '',
          email: '',
          phoneNum: '',
          city: '',
          fullName: '',
          latitude: 0.0,
          longitude: 0.0,
        );

  @override
  List<Object?> get props =>
      [uid, email, fullName, city, phoneNum, longitude, latitude];

  @override
  String toString() {
    return 'LocalUser{uid: $uid,latitude:$latitude,longitude:$longitude, fullName: $fullName, email: $email, phoneNum: $phoneNum, city: $city}';
  }
}
