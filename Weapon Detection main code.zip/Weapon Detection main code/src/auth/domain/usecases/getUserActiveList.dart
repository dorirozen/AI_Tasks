import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/auth/domain/entites/local_user.dart';
import 'package:guardian_view/src/auth/domain/repos/auth_repo.dart';

class GetUserActiveListUS extends UsecaseWithOutParams<List<LocalUser>> {
  const GetUserActiveListUS(this._authRepo);
  final AuthRepo _authRepo;
  @override
  ResultFuture<List<LocalUser>> call() => _authRepo.getUserActiveList();
}
