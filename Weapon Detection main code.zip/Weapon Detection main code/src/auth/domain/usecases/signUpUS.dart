import 'package:equatable/equatable.dart';
import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/auth/domain/repos/auth_repo.dart';

class SignUpUS extends UsecaseWithParams<void, SignUpParams> {
  const SignUpUS(this._authRepo);
  final AuthRepo _authRepo;
  @override
  ResultFuture<void> call(SignUpParams params) => _authRepo.signUp(
      email: params.email,
      fullName: params.fullName,
      city: params.city,
      phoneNum: params.phoneNum,
      password: params.password);
}

class SignUpParams extends Equatable {
  const SignUpParams(
      {required this.email,
      required this.fullName,
      required this.city,
      required this.phoneNum,
      required this.password});

  final String email;
  final String fullName;
  final String password;
  final String city;
  final String phoneNum;
  const SignUpParams.empty()
      : email = '',
        fullName = '',
        phoneNum = '',
        city = '',
        password = '';

  @override
  List<Object?> get props => [email, fullName, password, city, phoneNum];
}
