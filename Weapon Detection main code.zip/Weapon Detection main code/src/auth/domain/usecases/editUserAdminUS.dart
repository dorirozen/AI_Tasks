import 'package:equatable/equatable.dart';
import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/enums/update_user.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/auth/domain/entites/local_user.dart';
import 'package:guardian_view/src/auth/domain/repos/auth_repo.dart';

class EditUserAdminUS extends UsecaseWithParams<void, EditUserParams> {
  const EditUserAdminUS(this._authRepo);
  final AuthRepo _authRepo;
  @override
  ResultFuture<void> call(EditUserParams params) => _authRepo.editUserAdmin(
      action: params.action, userData: params.userData, user: params.user);
}

class EditUserParams extends Equatable {
  const EditUserParams(
      {required this.action, required this.userData, required this.user});
  final EditUserActionAdmin action;
  final dynamic userData;
  final LocalUser user;

  const EditUserParams.empty()
      : action = EditUserActionAdmin.displayName,
        userData = '',
        user = const LocalUser.empty();

  @override
  List<Object?> get props => [action, userData, user];
}
