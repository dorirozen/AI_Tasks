import 'package:flutter/material.dart';
import 'package:guardian_view/core/common/widgets/gradient_background.dart';
import 'package:guardian_view/core/resources/media_res.dart';
import 'package:guardian_view/main.dart';
import 'package:guardian_view/src/auth/presention/views/sign_in_screen.dart';
import 'package:guardian_view/src/profile/refactors/profile_body.dart';
import 'package:guardian_view/src/profile/refactors/profile_header.dart';
import 'package:provider/provider.dart';

import '../../../core/common/app/providers/user_provider.dart';
import '../../../core/resources/fonts.dart';
import '../../../core/services/getit/injection_container.main.dart';
import '../../alerts/presention/cubit/alert_cubit.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                width: 230,
                child: Text(
                  'Profile & Settings',
                  style: TextStyle(
                    color: Color(0xC7B42FC7), //Colors.black87,
                    fontFamily: Fonts.beautiful_people,
                    fontWeight: FontWeight.w900,
                    fontSize: 20,
                    shadows: [
                      Shadow(
                        offset: Offset(0, 3),
                        blurRadius: 5,
                        color: Colors.white12,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(width: 4),
              SizedBox(
                child: Image.asset(
                  'assets/images/projectLogo.png',
                  fit: BoxFit.contain,
                  width: 40,
                  height: 40,
                ),
              ),
            ],
          ),
        ),
      ),
      extendBodyBehindAppBar: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: GradientBackGround(
        needIconIsLive: true,
        toUse: true,
        darkenImage: true,
        image: MediaRes.backGroundProfile,
        child: ListView(
          //padding: const EdgeInsets.all(40),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
          scrollDirection: Axis.vertical,
          children: [
            SizedBox(
              height: 30,
            ),

            ///to show some details of the user \ admin
            const ProfileHeader(),

            ///only for admin
            const ProfileBody(),
            const SizedBox(height: 40),
            TextButton.icon(
              onPressed: () async {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) =>
                      const Center(child: CircularProgressIndicator()),
                );
                try {
                  await context.read<UserProvider>().signOut();

                  Navigator.of(context).pop(); // Dismiss the loading dialog
                  // sl<AlertCubit>().resumeSubscription();
                  Navigator.of(context)
                      .pushNamedAndRemoveUntil('/', (route) => false);
                } catch (e) {
                  Navigator.of(context).pop(); // Dismiss the loading dialog
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Sign out failed: $e')),
                  );
                }
              },
              icon: const Icon(
                Icons.logout,
                color: Colors.white,
                size: 28.0,
              ),
              label: const Text(
                'Logout',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
/*

import 'package:flutter/material.dart';
import 'package:guardian_view/core/common/widgets/gradient_background.dart';
import 'package:guardian_view/core/resources/media_res.dart';
import 'package:guardian_view/src/profile/refactors/profile_app_bar.dart';
import 'package:guardian_view/src/profile/refactors/profile_body.dart';
import 'package:guardian_view/src/profile/refactors/profile_header.dart';

import '../../../core/resources/fonts.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200.0,
            pinned: true,
            floating: false,
            flexibleSpace: LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                var top = constraints.biggest.height;
                return FlexibleSpaceBar(
                  centerTitle: true,
                  title: AnimatedOpacity(
                    duration: Duration(milliseconds: 300),
                    opacity: top < 120.0 ? 1.0 : 0.0,
                    child: Text(
                      'Profile',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                  background: Image.asset(
                    'assets/images/backGround.png',
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
            backgroundColor: Colors.transparent,
            elevation: 0.0,
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              Container(
                height:
                    1000, // Just for demonstration, replace with your content
                color: Colors.white,
                child: Column(
                  children: [
                    ProfileHeader(),
                    ProfileBody(),
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

 */
