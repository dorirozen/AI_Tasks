// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:guardian_view/core/common/app/providers/user_provider.dart';
// import 'package:guardian_view/core/extentions/context_extensions.dart';
// import 'package:guardian_view/core/services/getit/injection_container.main.dart';
// import 'package:guardian_view/src/auth/presention/bloc/auth_bloc.dart';
// import 'package:guardian_view/src/auth/presention/bloc/auth_event.dart';
// import 'package:guardian_view/src/profile/widgets/admin/admin_button.dart';
// import 'package:guardian_view/src/profile/edit_profile_view.dart';
// import 'package:iconly/iconly.dart';
// import 'package:provider/provider.dart';
// import '../../admin_cruds/presention/blocs/settings_bloc/settings_bloc.dart';
// import '../../admin_cruds/presention/blocs/settings_bloc/settings_event.dart';
// import '../../admin_cruds/presention/settings_pages/settings_ui.dart';
// import '../../admin_cruds/presention/user_pages/usersUI.dart';
//
// class ProfileBody extends StatefulWidget {
//   const ProfileBody({Key? key}) : super(key: key);
//
//   @override
//   State<ProfileBody> createState() => _ProfileBodyState();
// }
//
// class _ProfileBodyState extends State<ProfileBody> {
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<UserProvider>(
//       builder: (_, provider, __) {
//         //final user = provider.user;
//         return Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             const SizedBox(height: 40),
//             // for user
//             CoustomButton(
//               label: 'Changed something ?',
//               icon: IconlyLight.paper_upload,
//               onPressed: () {
//                 showModalBottomSheet<void>(
//                     context: context,
//                     backgroundColor: Colors.white,
//                     isScrollControlled: true,
//                     showDragHandle: false,
//                     elevation: 0,
//                     useSafeArea: true,
//                     builder: (_) => BlocProvider(
//                           create: (_) => sl<AuthBloc>(),
//                           child: const EditProfileView(),
//                         ));
//               },
//             ),
//
//             /// TODO: for admin
//             if (context.userProvider.user!.isAdmin) ...[
//               const SizedBox(height: 20),
//               CoustomButton(
//                 label: 'User setting',
//                 icon: IconlyLight.setting,
//                 onPressed: () {
//                   showModalBottomSheet<void>(
//                       context: context,
//                       backgroundColor: Colors.white,
//                       isScrollControlled: true,
//                       showDragHandle: false,
//                       elevation: 0,
//                       useSafeArea: true,
//                       builder: (_) => BlocProvider(
//                             create: (_) => sl<AuthBloc>()
//                               ..add(AuthEventGetUsers(
//                                   currentUser: context.currentUser!)),
//                             child: const AdminUserPage(),
//                           ));
//                 },
//               ),
//               SizedBox(
//                 height: 10.0.h,
//               ),
//               SizedBox(
//                 height: 10.0.h,
//               ),
//               CoustomButton(
//                 label: 'Global system setting',
//                 icon: IconlyLight.setting,
//                 onPressed: () {
//                   showModalBottomSheet<void>(
//                       context: context,
//                       backgroundColor: Colors.white,
//                       isScrollControlled: true,
//                       showDragHandle: false,
//                       elevation: 0,
//                       useSafeArea: true,
//                       builder: (_) => BlocProvider(
//                             create: (_) => sl<SettingsBloc>()
//                               ..add(const SettingEventGet()),
//                             child: const SettingsPage(),
//                           ));
//                 },
//               ),
//               SizedBox(
//                 height: 10.0.h,
//               ),
//             ],
//           ],
//           //UserInfoCard(infoThemeColor,infoIcon,infoTitle,infoValue)
//         );
//       },
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:guardian_view/core/common/app/providers/user_provider.dart';
import 'package:guardian_view/core/extentions/context_extensions.dart';
import 'package:guardian_view/core/services/getit/injection_container.main.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_bloc.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_event.dart';
import 'package:guardian_view/src/profile/widgets/admin/admin_button.dart';
import 'package:guardian_view/src/profile/edit_profile_view.dart';
import 'package:iconly/iconly.dart';
import 'package:provider/provider.dart';
import '../../admin_cruds/presention/blocs/settings_bloc/settings_bloc.dart';
import '../../admin_cruds/presention/blocs/settings_bloc/settings_event.dart';
import '../../admin_cruds/presention/settings_pages/settings_ui.dart';
import '../../admin_cruds/presention/user_pages/usersUI.dart';

class ProfileBody extends StatefulWidget {
  const ProfileBody({Key? key}) : super(key: key);

  @override
  State<ProfileBody> createState() => _ProfileBodyState();
}

class _ProfileBodyState extends State<ProfileBody> {
  @override
  Widget build(BuildContext context) {
    return Consumer<UserProvider>(
      builder: (_, provider, __) {
        final user = provider.user;

        if (user == null) {
          return Center(
            child: Text('No user data available. Please log in.'),
          );
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 40),
            // for user
            CoustomButton(
              label: 'Changed something?',
              icon: IconlyLight.paper_upload,
              onPressed: () {
                showModalBottomSheet<void>(
                    context: context,
                    backgroundColor: Colors.white,
                    isScrollControlled: true,
                    showDragHandle: false,
                    elevation: 0,
                    useSafeArea: true,
                    builder: (_) => BlocProvider(
                          create: (_) => sl<AuthBloc>(),
                          child: const EditProfileView(),
                        ));
              },
            ),

            // for admin
            if (user.isAdmin) ...[
              const SizedBox(height: 20),
              CoustomButton(
                label: 'User setting',
                icon: IconlyLight.setting,
                onPressed: () {
                  showModalBottomSheet<void>(
                      context: context,
                      backgroundColor: Colors.white,
                      isScrollControlled: true,
                      showDragHandle: false,
                      elevation: 0,
                      useSafeArea: true,
                      builder: (_) => BlocProvider(
                            create: (_) => sl<AuthBloc>()
                              ..add(AuthEventGetUsers(
                                  currentUser: context.currentUser!)),
                            child: const AdminUserPage(),
                          ));
                },
              ),
              SizedBox(
                height: 10.0.h,
              ),
              SizedBox(
                height: 10.0.h,
              ),
              CoustomButton(
                label: 'Global system setting',
                icon: IconlyLight.setting,
                onPressed: () {
                  showModalBottomSheet<void>(
                      context: context,
                      backgroundColor: Colors.white,
                      isScrollControlled: true,
                      showDragHandle: false,
                      elevation: 0,
                      useSafeArea: true,
                      builder: (_) => BlocProvider(
                            create: (_) => sl<SettingsBloc>()
                              ..add(const SettingEventGet()),
                            child: const SettingsPage(),
                          ));
                },
              ),
              SizedBox(
                height: 10.0.h,
              ),
            ],
          ],
        );
      },
    );
  }
}
