// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:guardian_view/core/common/app/providers/user_provider.dart';
// import 'package:guardian_view/src/alerts/domain/entities/alert_entity.dart';
// import 'package:guardian_view/src/alerts/presention/cubit/alert_cubit.dart';
// import 'package:guardian_view/src/video/presention/widgets/show_video.dart';
// import 'package:video_player/video_player.dart';
// import '../../../../core/resources/fonts.dart';
// import '../cubit/alert_state.dart';
// import 'package:url_launcher/url_launcher.dart';
// import 'dart:math' as math;
// import 'dart:async';
//
// class AlertListPage extends StatefulWidget {
//   const AlertListPage({super.key});
//
//   @override
//   State<AlertListPage> createState() => _AlertListPageState();
// }
//
// class _AlertListPageState extends State<AlertListPage>
//     with WidgetsBindingObserver {
//   final int batchSize = 1;
//   int loadedAlertsCount = 3;
//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addObserver(this);
//     debugPrint('alerts view initilize');
//   }
//
//   @override
//   void dispose() {
//     debugPrint('alerts view disposed');
//     WidgetsBinding.instance.removeObserver(this);
//     super.dispose();
//   }
//
//   @override
//   void didChangeAppLifecycleState(AppLifecycleState state) {
//     super.didChangeAppLifecycleState(state);
//     if (state == AppLifecycleState.detached) {}
//     if (state == AppLifecycleState.hidden) {}
//   }
//
//   int compareAlertLevels(String level1, String level2) {
//     final priorityOrder = {
//       'Emergency': 0,
//       'High': 1,
//       'Medium': 2,
//       'Low': 3,
//       'Resolved': 4
//     };
//
//     final priority1 =
//         priorityOrder[level1] ?? 999; // Default to lowest priority
//     final priority2 =
//         priorityOrder[level2] ?? 999; // Default to lowest priority
//
//     return priority1.compareTo(priority2);
//   }
//
//   double haversine(double lat1, double lon1, double lat2, double lon2) {
//     // Convert latitude and longitude from degrees to radians
//     lat1 = _degreesToRadians(lat1);
//     lon1 = _degreesToRadians(lon1);
//     lat2 = _degreesToRadians(lat2);
//     lon2 = _degreesToRadians(lon2);
//
//     // Haversine formula
//     double dlon = lon2 - lon1;
//     double dlat = lat2 - lat1;
//     double a = math.pow(math.sin(dlat / 2), 2) +
//         math.cos(lat1) * math.cos(lat2) * math.pow(math.sin(dlon / 2), 2);
//     double c = 2 * math.asin(math.sqrt(a));
//
//     double r = 6371.0; // Radius of the Earth in kilometers
//
//     // Calculate the result
//     double distance = c * r;
//     return distance;
//   }
//
//   double _degreesToRadians(double degrees) {
//     return degrees * math.pi / 180;
//   }
//
//   List<Alert> sortAlertsBySeverityAndDistance(
//       List<Alert> alerts, double userLatitude, double userLongitude) {
//     alerts.sort((a, b) => compareAlertLevels(a.severity, b.severity));
//
//     // Now sort within each severity level by distance
//     alerts.sort((a, b) {
//       final distance1 = haversine(
//           a.latitude ?? 0, a.longitude ?? 0, userLatitude, userLongitude);
//       final distance2 = haversine(
//           b.latitude ?? 0, b.longitude ?? 0, userLatitude, userLongitude);
//
//       if (distance1 < 0.1 && distance2 >= 0.1) {
//         return -1; // a is closer, should come first
//       } else if (distance1 >= 0.1 && distance2 < 0.1) {
//         return 1; // b is closer, should come first
//       } else {
//         return 0; // distances are either both close or both not close
//       }
//     });
//
//     return alerts;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     context.read<AlertCubit>().resumeSubscription();
//     bool? isAdmin = context.read<UserProvider>().user?.isAdmin;
//     return Scaffold(
//       appBar: AppBar(
//         title: Center(
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const SizedBox(
//                 width: 230,
//                 child: Text(
//                   'Detection Alerts',
//                   style: TextStyle(
//                     color: Colors.black54,
//                     fontFamily: Fonts.beautiful_people,
//                     fontWeight: FontWeight.w900,
//                     fontSize: 25,
//                     shadows: [
//                       Shadow(
//                         offset: Offset(0, 3),
//                         blurRadius: 5,
//                         color: Colors.white12,
//                       ),
//                     ],
//                   ),
//                   textAlign: TextAlign.center,
//                 ),
//               ),
//               const SizedBox(width: 4),
//               SizedBox(
//                 child: Image.asset(
//                   'assets/images/projectLogo.png',
//                   fit: BoxFit.contain,
//                   width: 40,
//                   height: 40,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//       body: BlocBuilder<AlertCubit, AlertState>(
//         builder: (context, state) {
//           if (state is AlertStateInitial) {
//             return const Center(child: Text('Initializing...'));
//           } else if (state is AlertStateLoading) {
//             return const Center(child: CircularProgressIndicator());
//           } else if (state is AlertStateLoaded) {
//             final alerts = state.alertsList;
//             alerts.sort((a, b) => compareAlertLevels(a.severity, b.severity));
//             //TODO: add here the location of the user..
//             // + needs to fake locations!! and details...
//             final user = context.read<UserProvider>().user!;
//             List<Alert> userSortedAlerts = sortAlertsBySeverityAndDistance(
//                 state.alertsList,
//                 user.latitude ?? 23.09,
//                 user.longitude ?? 41.121);
//             final displayedAlerts = isAdmin!
//                 ? alerts
//                 : userSortedAlerts
//                     .where((alert) =>
//                         (alert.isConfirmed || alert.severity == 'Emergency') &&
//                         alert.severity != 'Resolved')
//                     .toList();
//
//             final alertsToShow =
//                 displayedAlerts.take(loadedAlertsCount).toList();
//
//             if (alertsToShow.isEmpty) {
//               return const Center(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Icon(
//                       Icons.info_outline,
//                       color: Colors.blueAccent,
//                       size: 50,
//                     ),
//                     SizedBox(height: 20),
//                     Text(
//                       'No alerts found!',
//                       style: TextStyle(
//                         color: Colors.black54,
//                         fontFamily: 'Roboto',
//                         fontWeight: FontWeight.w600,
//                         fontSize: 20,
//                         shadows: [
//                           Shadow(
//                             offset: Offset(0, 2),
//                             blurRadius: 4,
//                             color: Colors.black26,
//                           ),
//                         ],
//                       ),
//                       textAlign: TextAlign.center,
//                     ),
//                     SizedBox(height: 10),
//                     Text(
//                       'You are all caught up',
//                       style: TextStyle(
//                         color: Colors.black45,
//                         fontFamily: 'Roboto',
//                         fontWeight: FontWeight.w400,
//                         fontSize: 16,
//                       ),
//                       textAlign: TextAlign.center,
//                     ),
//                   ],
//                 ),
//               );
//             }
//
//             return Column(
//               children: [
//                 Expanded(
//                   child: ListView.builder(
//                     itemCount: alertsToShow.length,
//                     itemBuilder: (context, index) {
//                       final alert = alertsToShow[index];
//                       double lat1 = alert.latitude ?? 31.9803889;
//                       double lon1 = alert.longitude ?? 34.8158181;
//                       double lat2 = 31.9803889;
//                       double lon2 = 34.8130534;
//
//                       double distance = haversine(lat1, lon1, lat2, lon2);
//                       return AlertCard(
//                         alert: alert,
//                         isClose: distance > 1000,
//                       );
//                     },
//                   ),
//                 ),
//                 if (loadedAlertsCount < displayedAlerts.length) ...[
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       ElevatedButton(
//                         onPressed: loadMoreAlerts,
//                         child: const Text('Load More'),
//                       ),
//                       const SizedBox(width: 16),
//                       ElevatedButton(
//                         onPressed: () => loadAllAlerts(displayedAlerts.length),
//                         child: const Text('Load All'),
//                       ),
//                     ],
//                   )
//                 ]
//               ],
//             );
//           } else if (state is AlertStateError) {
//             return Center(
//               child: Text('Error: ${state.message}'),
//             );
//           } else {
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           }
//         },
//       ),
//     );
//   }
//
//   void loadMoreAlerts() {
//     setState(() {
//       loadedAlertsCount = loadedAlertsCount + batchSize;
//     });
//   }
//
//   void loadAllAlerts(int totalAlerts) {
//     setState(() {
//       loadedAlertsCount = totalAlerts;
//     });
//   }
// }
//
// class AlertCard extends StatefulWidget {
//   final Alert alert;
//   final bool isClose;
//
//   const AlertCard({super.key, required this.alert, this.isClose = false});
//   @override
//   _AlertCardState createState() => _AlertCardState();
// }
//
// class _AlertCardState extends State<AlertCard>
//     with SingleTickerProviderStateMixin {
//   VideoPlayerController? controller;
//   late AnimationController _controller;
//   late Animation<Color?> _colorAnimation;
//   bool isExpanded = false;
//   bool _animationActive = false;
//   late Timer _timer;
//   bool _buttonsVisible = true;
//   void _initializeVideoPlayer() {
//     if (widget.alert.videoUrl != null) {
//       final videoUri = Uri.parse(widget.alert.videoUrl!);
//       controller = VideoPlayerController.networkUrl(videoUri)
//         ..addListener(() => setState(() {}))
//         ..setLooping(true)
//         ..initialize().then((_) => setState(() {}));
//     }
//   }
//
//   void _disposeVideoPlayer() {
//     if (widget.alert.videoUrl != null) {
//       controller?.removeListener(() => setState(() {}));
//       controller?.dispose();
//       controller = null;
//     }
//   }
//
//   void _launchMaps(double latitude, double longitude) async {
//     final Uri url = Uri.parse(
//         'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');
//     debugPrint('Attempting to launch URL: $url');
//     try {
//       await launchUrl(
//         url,
//         mode: LaunchMode.platformDefault, // Try platformDefault
//       );
//       debugPrint("launched to the url.");
//     } catch (e) {
//       debugPrint('$e');
//     }
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     _controller = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 1000),
//     );
//
//     _colorAnimation =
//         ColorTween(begin: Colors.white, end: Colors.red).animate(_controller);
//
//     if (widget.isClose) {
//       _startAnimation();
//     } else {
//       _timer = Timer(const Duration(seconds: 4), () {});
//     }
//   }
//
//   void _startAnimation() {
//     _animationActive = true;
//     _controller.repeat(reverse: true); // Start the animation in a loop
//
//     // Timer to stop the animation after 10 seconds
//     _timer = Timer(const Duration(seconds: 4), () {
//       _stopAnimation();
//     });
//   }
//
//   void _stopAnimation() {
//     _animationActive = false;
//     _controller.stop();
//     _timer.cancel();
//   }
//
//   @override
//   void dispose() {
//     _disposeVideoPlayer();
//     _controller.dispose();
//     controller?.dispose();
//     _timer.cancel();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final isAdmin = context.read<UserProvider>().user?.isAdmin ?? false;
//     return AnimatedBuilder(
//         animation: _controller,
//         builder: (context, child) {
//           return Card(
//             elevation: 4,
//             margin: const EdgeInsets.all(8),
//             color: widget.isClose && _animationActive
//                 ? _colorAnimation.value
//                 : Colors.white,
//             child: ExpansionTile(
//               leading: getLevelIcon(widget.alert.severity), // Status Icon
//               title: Column(
//                 children: [
//                   if (widget.isClose) ...[
//                     const Text(
//                       'You are very close to the scene!',
//                       style: TextStyle(fontWeight: FontWeight.bold),
//                     ),
//                     const SizedBox(
//                       height: 5.0,
//                     ),
//                   ],
//                   Text(
//                     'severity: ${widget.alert.severity}',
//                     style: const TextStyle(fontWeight: FontWeight.bold),
//                   ),
//                 ],
//               ), // Alert title
//               subtitle: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text('Alert Type: ${widget.alert.alertType}'),
//                   Text('Confidence: ${widget.alert.confidence}'),
//                   Text('Source: ${widget.alert.source}'),
//                   Text(
//                       'Location: ${widget.alert.location == 'locationTODO' || widget.alert.location == null ? 'Unknown' : widget.alert.location}'),
//                   Text('Time: ${widget.alert.timestamp}'),
//                 ],
//               ),
//               onExpansionChanged: (expanded) {
//                 setState(() {
//                   isExpanded = expanded;
//                   if (isExpanded) {
//                     _initializeVideoPlayer();
//                   } else {
//                     _disposeVideoPlayer();
//                   }
//                 });
//               },
//               trailing: isExpanded
//                   ? const Icon(Icons.expand_less)
//                   : const Icon(Icons.expand_more),
//               children: <Widget>[
//                 if (widget.alert.severity != "Resolved")
//                   //if (_buttonsVisible)
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Visibility(
//                         visible: isAdmin,
//                         child: ElevatedButton.icon(
//                           onPressed: () {
//                             final alertCubit = context.read<AlertCubit>();
//                             if (alertCubit.isClosed) {
//                               debugPrint(
//                                   'AlertCubit is closed when button pressed');
//                               // Optionally, show a message to the user or handle this case
//                             } else {
//                               alertCubit.updateAlertConfirmationStatus(
//                                   widget.alert.id);
//                             }
//                           },
//                           icon: Icon(
//                             widget.alert.isConfirmed
//                                 ? Icons.check_circle
//                                 : Icons.check_circle_outline,
//                             color: widget.alert.isConfirmed
//                                 ? Colors.green
//                                 : Colors.grey,
//                           ),
//                           label: const Text('Confirm Alert'),
//                         ),
//                       ),
//                       Visibility(
//                         visible: isAdmin,
//                         child: ElevatedButton.icon(
//                           onPressed: () {
//                             final alertCubit = context.read<AlertCubit>();
//                             if (alertCubit.isClosed) {
//                               debugPrint(
//                                   'AlertCubit is closed when button pressed');
//                               // Optionally, show a message to the user or handle this case
//                             } else {
//                               alertCubit
//                                   .updateAlertResolvedStatus(widget.alert.id);
//                               // setState(() {
//                               //   _buttonsVisible = false;
//                               // });
//                             }
//                           },
//                           icon: Icon(
//                             widget.alert.severity == 'Resolved'
//                                 ? Icons.check_circle
//                                 : Icons.check_circle_outline,
//                             color: widget.alert.severity == 'Resolved'
//                                 ? Colors.green
//                                 : Colors.grey,
//                           ),
//                           label: const Text('Resolved ?'),
//                         ),
//                       ),
//                     ],
//                   ),
//                 if (widget.alert.severity != "Resolved") ...[
//                   ElevatedButton(
//                     // TODO: to changee for the real user !!!
//                     onPressed: () {
//                       // Replace with your desired latitude and longitude
//                       _launchMaps(widget.alert.latitude ?? 32.1226141,
//                           widget.alert.longitude ?? 34.8168357);
//                     },
//                     child: const Text('Navigate to destination'),
//                   ),
//                 ],
//                 if (widget.alert.videoUrl != null) ...[
//                   Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 16.0, vertical: 8.0),
//                     child: VideoPlayerWidget(controller: controller),
//                   ),
//                 ],
//                 Padding(
//                   padding: const EdgeInsets.symmetric(
//                       horizontal: 16.0, vertical: 8.0),
//                   child: Text('Description: ${widget.alert.description}',
//                       style: const TextStyle(fontSize: 16)),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.all(8.0),
//                   child: SizedBox(
//                     width: double.infinity, // Adjust this as needed
//                     height: 200, // Adjust this as needed
//                     child: Image.network(
//                       widget.alert.imageUrl,
//                       fit: BoxFit.cover, // Adjust this as needed
//                       loadingBuilder: (BuildContext context, Widget child,
//                           ImageChunkEvent? loadingProgress) {
//                         if (loadingProgress == null) {
//                           return child;
//                         } else {
//                           return Center(
//                             child: CircularProgressIndicator(
//                               value: loadingProgress.expectedTotalBytes != null
//                                   ? loadingProgress.cumulativeBytesLoaded /
//                                       loadingProgress.expectedTotalBytes!
//                                   : null,
//                             ),
//                           );
//                         }
//                       },
//                       errorBuilder: (BuildContext context, Object exception,
//                           StackTrace? stackTrace) {
//                         return const Center(
//                           child: Text('Failed to load image'),
//                         );
//                       },
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           );
//         });
//   }
// }
//
// Icon getLevelIcon(String levelString) {
//   switch (levelString) {
//     case 'Emergency':
//       return const Icon(Icons.warning,
//           color: Colors.red); // or any other emergency icon
//     case 'High':
//       return const Icon(Icons.error,
//           color: Colors.redAccent); // or any other high-level icon
//     case 'Medium':
//       return const Icon(Icons.warning_amber,
//           color: Colors.yellow); // or any other medium-level icon
//     case 'Low':
//       return const Icon(Icons.info,
//           color: Colors.green); // or any other low-level icon
//     case 'Resolved':
//       return const Icon(Icons.check, color: Colors.black);
//     default:
//       return const Icon(Icons.info, color: Colors.black); // Default icon
//   }
// }
//
// /*import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:guardian_view/core/common/app/providers/user_provider.dart';
// import 'package:guardian_view/src/alerts/domain/entities/alert_entity.dart';
// import 'package:guardian_view/src/alerts/presention/cubit/alert_cubit.dart';
// import 'package:guardian_view/src/video/presention/widgets/show_video.dart';
// import 'package:video_player/video_player.dart';
// import '../cubit/alert_state.dart';
//
// class AlertListPage extends StatefulWidget {
//   const AlertListPage({super.key});
//
//   @override
//   State<AlertListPage> createState() => _AlertListPageState();
// }
//
// class _AlertListPageState extends State<AlertListPage>
//     with WidgetsBindingObserver {
//   final int batchSize = 1;
//   int loadedAlertsCount = 1;
//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addObserver(this);
//     debugPrint('initilize');
//   }
//
//   @override
//   void dispose() {
//     debugPrint('disposed');
//     WidgetsBinding.instance.removeObserver(this);
//     super.dispose();
//     debugPrint('disposed');
//   }
//
//   @override
//   void didChangeAppLifecycleState(AppLifecycleState state) {
//     super.didChangeAppLifecycleState(state);
//     if (state == AppLifecycleState.detached) {
//       debugPrint('found it !!!');
//     }
//     if (state == AppLifecycleState.hidden) {
//       debugPrint('found it2222 !!!');
//     }
//   }
//
//   int compareAlertLevels(String level1, String level2) {
//     final priorityOrder = {
//       'emergency': 0,
//       'high': 1,
//       'medium': 2,
//       'low': 3,
//       'resolved': 4
//     };
//
//     final priority1 =
//         priorityOrder[level1] ?? 999; // Default to lowest priority
//     final priority2 =
//         priorityOrder[level2] ?? 999; // Default to lowest priority
//
//     return priority1.compareTo(priority2);
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     context.read<AlertCubit>().resumeSubscription();
//     bool? isAdmin = context.read<UserProvider>().user?.isAdmin;
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Weapon Detection Alerts'),
//       ),
//       body: BlocBuilder<AlertCubit, AlertState>(
//         builder: (context, state) {
//           if (state is AlertStateLoaded && state.alertsList.isEmpty) {
//             return const Center(
//               child: Text('Empty !', style: TextStyle(color: Colors.black)),
//             );
//           }
//           if (state is AlertStateLoaded) {
//             final alerts = state.alertsList;
//             alerts.sort((a, b) => compareAlertLevels(a.severity, b.severity));
//             return Column(
//               children: [
//                 Expanded(
//                   child: ListView.builder(
//                     itemCount: loadedAlertsCount,
//                     itemBuilder: (context, index) {
//                       final alert = alerts[index];
//                       if (isAdmin!) {
//                         return AlertCard(alert: alert);
//                       }
//                       if (!isAdmin &&
//                           alert.isConfirmed &&
//                           alert.severity != 'resolved') {
//                         // If user is not admin, show only confirmed alerts
//                         return AlertCard(alert: alert);
//                       }
//                       return const SizedBox
//                           .shrink(); // Skip building other alerts
//                     },
//                   ),
//                 ),
//                 if (loadedAlertsCount < alerts.length) ...[
//                   Row(
//                     children: [
//                       ElevatedButton(
//                         onPressed: loadMoreAlerts,
//                         child: const Text('Load More'),
//                       ),
//                       ElevatedButton(
//                         onPressed: () => loadAllAlerts(state),
//                         child: const Text('Load All'),
//                       ),
//                     ],
//                   )
//                 ]
//               ],
//             );
//           } else if (state is AlertStateError) {
//             return Center(
//               child: Text('Error: ${state.message}'),
//             );
//           } else {
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           }
//         },
//       ),
//     );
//   }
//
//   void loadMoreAlerts() {
//     setState(() {
//       loadedAlertsCount = loadedAlertsCount + batchSize;
//     });
//   }
//
//   void loadAllAlerts(AlertStateLoaded state) {
//     setState(() {
//       loadedAlertsCount = state.alertsList.length;
//     });
//   }
// }
//
// class AlertCard extends StatefulWidget {
//   final Alert alert;
//
//   const AlertCard({super.key, required this.alert});
//   @override
//   _AlertCardState createState() => _AlertCardState();
// }
//
// class _AlertCardState extends State<AlertCard> {
//   VideoPlayerController? controller;
//
//   bool isExpanded = false;
//
//   void _initializeVideoPlayer() {
//     if (widget.alert.videoUrl != null) {
//       final videoUri = Uri.parse(widget.alert.videoUrl!);
//       controller = VideoPlayerController.networkUrl(videoUri)
//         ..addListener(() => setState(() {}))
//         ..setLooping(true)
//         ..initialize().then((_) => setState(() {}));
//     }
//   }
//
//   void _disposeVideoPlayer() {
//     if (widget.alert.videoUrl != null) {
//       controller?.removeListener(() => setState(() {}));
//       controller?.dispose();
//       controller = null;
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final icon = getLevelIcon(widget.alert.severity);
//     bool? isAdmin = context.read<UserProvider>().user?.isAdmin;
//     return Card(
//       child: ExpansionTile(
//         leading: icon, // Status Icon
//         title: Text(
//             'severity: ${widget.alert.severity}, AlertType: ${widget.alert.alertType}, Confidence: ${widget.alert.confidence}'), // Alert title
//         subtitle: Text(
//             'Source: ${widget.alert.source}, Location: ${widget.alert.location ?? 'unKnown'}, Time: ${widget.alert.timestamp}'), // Location & Time
//
//         onExpansionChanged: (expanded) {
//           setState(() {
//             isExpanded = expanded;
//             if (isExpanded) {
//               _initializeVideoPlayer();
//             } else {
//               _disposeVideoPlayer();
//             }
//           });
//         },
//         children: <Widget>[
//           Visibility(
//             visible: isAdmin!,
//             child: ElevatedButton.icon(
//               onPressed: () {
//                 context
//                     .read<AlertCubit>()
//                     .updateAlertConfirmationStatus(widget.alert.id);
//               },
//               icon: Icon(
//                 widget.alert.isConfirmed
//                     ? Icons.check_circle
//                     : Icons.check_circle_outline,
//                 color: widget.alert.isConfirmed ? Colors.green : Colors.grey,
//               ),
//               label: const Text('Confirm Alert'),
//             ),
//           ),
//           if (widget.alert.videoUrl != null) ...[
//             Padding(
//               padding:
//                   const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//               child: VideoPlayerWidget(controller: controller),
//             ),
//           ],
//           Padding(
//             padding:
//                 const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//             child: Text('Description: ${widget.alert.description}',
//                 style: const TextStyle(fontSize: 16)),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: SizedBox(
//               width: double.infinity, // Adjust this as needed
//               height: 200, // Adjust this as needed
//               child: Image.network(
//                 widget.alert.imageUrl,
//                 fit: BoxFit.cover, // Adjust this as needed
//                 loadingBuilder: (BuildContext context, Widget child,
//                     ImageChunkEvent? loadingProgress) {
//                   if (loadingProgress == null) {
//                     return child;
//                   } else {
//                     return Center(
//                       child: CircularProgressIndicator(
//                         value: loadingProgress.expectedTotalBytes != null
//                             ? loadingProgress.cumulativeBytesLoaded /
//                                 loadingProgress.expectedTotalBytes!
//                             : null,
//                       ),
//                     );
//                   }
//                 },
//                 errorBuilder: (BuildContext context, Object exception,
//                     StackTrace? stackTrace) {
//                   return const Center(
//                     child: Text('Failed to load image'),
//                   );
//                 },
//               ),
//             ),
//           )
//         ],
//       ),
//     );
//   }
//
//   @override
//   void dispose() {
//     _disposeVideoPlayer();
//     super.dispose();
//   }
// }
//
// Icon getLevelIcon(String levelString) {
//   switch (levelString) {
//     case 'emergency':
//       return const Icon(Icons.warning,
//           color: Colors.red); // or any other emergency icon
//     case 'high':
//       return const Icon(Icons.error,
//           color: Colors.redAccent); // or any other high-level icon
//     case 'medium':
//       return const Icon(Icons.warning_amber,
//           color: Colors.yellow); // or any other medium-level icon
//     case 'low':
//       return const Icon(Icons.info,
//           color: Colors.green); // or any other low-level icon
//     case 'resolved':
//       return const Icon(Icons.check, color: Colors.black);
//     default:
//       return const Icon(Icons.info, color: Colors.black); // Default icon
//   }
// }
// */

// chat version

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/core/common/app/providers/user_provider.dart';
import 'package:guardian_view/src/alerts/domain/entities/alert_entity.dart';
import 'package:guardian_view/src/alerts/presention/cubit/alert_cubit.dart';
import 'package:guardian_view/src/video/presention/widgets/show_video.dart';
import 'package:video_player/video_player.dart';
import '../../../../core/resources/fonts.dart';
import '../cubit/alert_state.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'dart:math';

class AlertListPage extends StatefulWidget {
  const AlertListPage({super.key});

  @override
  State<AlertListPage> createState() => _AlertListPageState();
}

class _AlertListPageState extends State<AlertListPage>
    with WidgetsBindingObserver {
  final int batchSize = 1;
  int loadedAlertsCount = 3;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final userProvider = context.read<UserProvider>();
    final firebaseUser = FirebaseAuth.instance.currentUser;
    if (firebaseUser != null) {
      userProvider.initUserFromFirebase(firebaseUser);
    }
    debugPrint('alerts view initilize');
  }

  @override
  void dispose() {
    debugPrint('alerts view disposed');
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.detached) {}
    if (state == AppLifecycleState.hidden) {}
  }

  int compareAlertLevels(String level1, String level2) {
    final priorityOrder = {
      'Emergency': 0,
      'High': 1,
      'Medium': 2,
      'Low': 3,
      'Resolved': 4
    };

    int priority1 = priorityOrder[level1] ?? 999; // Default to lowest priority
    int priority2 = priorityOrder[level2] ?? 999; // Default to lowest priority
    return priority1.compareTo(priority2);
  }

  double haversine(double lat1, double lon1, double lat2, double lon2) {
    // Log the inputs for debugging
    //print('Calculating distance from ($lat1, $lon1) to ($lat2, $lon2)');

    double dlon = _degreesToRadians(lon2 - lon1);
    double dlat = _degreesToRadians(lat2 - lat1);
    double a = pow(sin(dlat / 2), 2) +
        cos(_degreesToRadians(lat1)) *
            cos(_degreesToRadians(lat2)) *
            pow(sin(dlon / 2), 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    double r = 6371.0; // Radius of the Earth in kilometers
    double distance = c * r * 1000; // Convert to meters
    //print('Computed distance: $distance meters');
    return distance;
  }

  double? safeHaversine(
      double? lat1, double? lon1, double? lat2, double? lon2) {
    if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) {
      print('Null latitude/longitude provided');
      return null;
    }
    return haversine(lat1, lon1, lat2, lon2);
  }

  List<Alert> sortAlertsBySeverityAndDistance(
      List<Alert> alerts, double userLatitude, double userLongitude) {
    // Calculate distance once and store it in a map to avoid recalculating
    Map<Alert, double> distanceMap = {};
    for (var alert in alerts) {
      double? distance = safeHaversine(
          alert.latitude, alert.longitude, userLatitude, userLongitude);
      if (distance != null) {
        distanceMap[alert] = distance;
      } else {
        distanceMap[alert] =
            double.infinity; // Assign a large value for missing data
      }
    }

    // Sort by severity
    alerts.sort((a, b) => compareAlertLevels(a.severity, b.severity));

    // Further sort each severity level by distance using precomputed distances
    Map<String, List<Alert>> groupedBySeverity = {};
    for (var alert in alerts) {
      groupedBySeverity.putIfAbsent(alert.severity, () => []).add(alert);
    }

    List<Alert> sortedAlerts = [];
    groupedBySeverity.forEach((severity, group) {
      group.sort((a, b) => distanceMap[a]!.compareTo(distanceMap[b]!));
      sortedAlerts.addAll(group);
    });

    return sortedAlerts;
  }

  double _degreesToRadians(double degrees) {
    return degrees * pi / 180;
  }

  @override
  Widget build(BuildContext context) {
    context.read<AlertCubit>().resumeSubscription();
    final user = context.watch<UserProvider>().user;
    final bool? isAdmin = user?.isAdmin;

    if (user == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                width: 230,
                child: Text(
                  'Detection Alerts',
                  style: TextStyle(
                    color: Colors.black54,
                    fontFamily: Fonts.beautiful_people,
                    fontWeight: FontWeight.w900,
                    fontSize: 25,
                    shadows: [
                      Shadow(
                        offset: Offset(0, 3),
                        blurRadius: 5,
                        color: Colors.white12,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(width: 4),
              SizedBox(
                child: Image.asset(
                  'assets/images/projectLogo.png',
                  fit: BoxFit.contain,
                  width: 40,
                  height: 40,
                ),
              ),
            ],
          ),
        ),
      ),
      body: BlocBuilder<AlertCubit, AlertState>(
        builder: (context, state) {
          if (state is AlertStateInitial) {
            return const Center(child: Text('Initializing...'));
          } else if (state is AlertStateLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is AlertStateLoaded) {
            List<Alert> sortedAlerts = sortAlertsBySeverityAndDistance(
                state.alertsList, user!.latitude!, user.longitude!);
            final List<Alert> alertsToShow = isAdmin!
                ? state.alertsList
                : sortedAlerts
                    .where((alert) =>
                        (alert.isConfirmed || alert.severity == 'Emergency') &&
                        alert.severity != 'Resolved')
                    .toList();
            final List<Alert> displayedAlerts =
                alertsToShow.take(loadedAlertsCount).toList();
            if (alertsToShow.isEmpty) {
              return const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: Colors.blueAccent,
                      size: 50,
                    ),
                    SizedBox(height: 20),
                    Text(
                      'No alerts found!',
                      style: TextStyle(
                        color: Colors.black54,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w600,
                        fontSize: 20,
                        shadows: [
                          Shadow(
                            offset: Offset(0, 2),
                            blurRadius: 4,
                            color: Colors.black26,
                          ),
                        ],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'You are all caught up',
                      style: TextStyle(
                        color: Colors.black45,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              );
            }

            return Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: displayedAlerts.length,
                    itemBuilder: (context, index) {
                      final alert = displayedAlerts[index];
                      double distance = haversine(user.latitude!,
                          user.longitude!, alert.latitude!, alert.longitude!);
                      bool isClose = distance < 1000;
                      return AlertCard(alert: alert, isClose: isClose);
                    },
                  ),
                ),
                if (loadedAlertsCount < alertsToShow.length) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: loadMoreAlerts,
                        child: const Text('Load More'),
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton(
                        onPressed: () => loadAllAlerts(alertsToShow.length),
                        child: const Text('Load All'),
                      ),
                    ],
                  )
                ]
              ],
            );
          } else if (state is AlertStateError) {
            return Center(
              child: Text('Error: ${state.message}'),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }

  void loadMoreAlerts() {
    setState(() {
      loadedAlertsCount = loadedAlertsCount + batchSize;
    });
  }

  void loadAllAlerts(int totalAlerts) {
    setState(() {
      loadedAlertsCount = totalAlerts;
    });
  }
}

class AlertCard extends StatefulWidget {
  final Alert alert;
  final bool isClose;

  const AlertCard({super.key, required this.alert, this.isClose = false});
  @override
  _AlertCardState createState() => _AlertCardState();
}

class _AlertCardState extends State<AlertCard>
    with SingleTickerProviderStateMixin {
  VideoPlayerController? controller;
  late AnimationController _controller;
  late Animation<Color?> _colorAnimation;
  bool isExpanded = false;
  bool _animationActive = false;
  late Timer _timer;
  void _initializeVideoPlayer() {
    if (widget.alert.videoUrl != null) {
      final videoUri = Uri.parse(widget.alert.videoUrl!);
      controller = VideoPlayerController.networkUrl(videoUri)
        ..addListener(() => setState(() {}))
        ..setLooping(true)
        ..initialize().then((_) => setState(() {}));
    }
  }

  void _disposeVideoPlayer() {
    if (widget.alert.videoUrl != null) {
      controller?.removeListener(() => setState(() {}));
      controller?.dispose();
      controller = null;
    }
  }

  void _launchMaps(double latitude, double longitude) async {
    final Uri url = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');
    debugPrint('Attempting to launch URL: $url');
    try {
      await launchUrl(
        url,
        mode: LaunchMode.platformDefault, // Try platformDefault
      );
      debugPrint("launched to the url.");
    } catch (e) {
      debugPrint('$e');
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _colorAnimation =
        ColorTween(begin: Colors.white, end: Colors.red).animate(_controller);

    if (widget.isClose) {
      _startAnimation();
    } else {
      _timer = Timer(const Duration(seconds: 4), () {});
    }
  }

  void _startAnimation() {
    _animationActive = true;
    _controller.repeat(reverse: true); // Start the animation in a loop

    // Timer to stop the animation after 10 seconds
    _timer = Timer(const Duration(seconds: 4), () {
      _stopAnimation();
    });
  }

  void _stopAnimation() {
    _animationActive = false;
    _controller.stop();
    _timer.cancel();
  }

  @override
  void dispose() {
    _disposeVideoPlayer();
    _controller.dispose();
    controller?.dispose();
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = context.read<UserProvider>().user?.isAdmin ?? false;
    return AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Card(
            elevation: 4,
            margin: const EdgeInsets.all(8),
            color: widget.isClose && _animationActive
                ? _colorAnimation.value
                : Colors.white,
            child: ExpansionTile(
              leading: getLevelIcon(widget.alert.severity), // Status Icon
              title: Column(
                children: [
                  if (widget.isClose) ...[
                    const Text(
                      'You are very close to the scene!',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 5.0,
                    ),
                  ],
                  Text(
                    'severity: ${widget.alert.severity}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ), // Alert title
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Alert Type: ${widget.alert.alertType}'),
                  Text('Confidence: ${widget.alert.confidence}'),
                  Text('Source: ${widget.alert.source}'),
                  Text(
                      'Location: ${widget.alert.location == 'locationTODO' || widget.alert.location == null ? 'Unknown' : widget.alert.location}'),
                  Text('Time: ${widget.alert.timestamp}'),
                ],
              ),
              onExpansionChanged: (expanded) {
                setState(() {
                  isExpanded = expanded;
                  if (isExpanded) {
                    _initializeVideoPlayer();
                  } else {
                    _disposeVideoPlayer();
                  }
                });
              },
              trailing: isExpanded
                  ? const Icon(Icons.expand_less)
                  : const Icon(Icons.expand_more),
              children: <Widget>[
                if (widget.alert.severity != "Resolved")
                  //if (_buttonsVisible)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Visibility(
                        visible: isAdmin,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            final alertCubit = context.read<AlertCubit>();
                            if (alertCubit.isClosed) {
                              debugPrint(
                                  'AlertCubit is closed when button pressed');
                              // Optionally, show a message to the user or handle this case
                            } else {
                              alertCubit.updateAlertConfirmationStatus(
                                  widget.alert.id);
                            }
                          },
                          icon: Icon(
                            widget.alert.isConfirmed
                                ? Icons.check_circle
                                : Icons.check_circle_outline,
                            color: widget.alert.isConfirmed
                                ? Colors.green
                                : Colors.grey,
                          ),
                          label: const Text('Confirm Alert'),
                        ),
                      ),
                      Visibility(
                        visible: isAdmin,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            final alertCubit = context.read<AlertCubit>();
                            if (alertCubit.isClosed) {
                              debugPrint(
                                  'AlertCubit is closed when button pressed');
                              // Optionally, show a message to the user or handle this case
                            } else {
                              alertCubit
                                  .updateAlertResolvedStatus(widget.alert.id);
                              // setState(() {
                              //   _buttonsVisible = false;
                              // });
                            }
                          },
                          icon: Icon(
                            widget.alert.severity == 'Resolved'
                                ? Icons.check_circle
                                : Icons.check_circle_outline,
                            color: widget.alert.severity == 'Resolved'
                                ? Colors.green
                                : Colors.grey,
                          ),
                          label: const Text('Resolved ?'),
                        ),
                      ),
                    ],
                  ),
                if (widget.alert.severity != "Resolved") ...[
                  ElevatedButton(
                    // TODO: to changee for the real user !!!
                    onPressed: () {
                      // Replace with your desired latitude and longitude
                      _launchMaps(widget.alert.latitude ?? 32.1226141,
                          widget.alert.longitude ?? 34.8168357);
                    },
                    child: const Text('Navigate to destination'),
                  ),
                ],
                if (widget.alert.videoUrl != null) ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    child: VideoPlayerWidget(controller: controller),
                  ),
                ],
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16.0, vertical: 8.0),
                  child: Text('Description: ${widget.alert.description}',
                      style: const TextStyle(fontSize: 16)),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    width: double.infinity, // Adjust this as needed
                    height: 200, // Adjust this as needed
                    child: Image.network(
                      widget.alert.imageUrl,
                      fit: BoxFit.cover, // Adjust this as needed
                      loadingBuilder: (BuildContext context, Widget child,
                          ImageChunkEvent? loadingProgress) {
                        if (loadingProgress == null) {
                          return child;
                        } else {
                          return Center(
                            child: CircularProgressIndicator(
                              value: loadingProgress.expectedTotalBytes != null
                                  ? loadingProgress.cumulativeBytesLoaded /
                                      loadingProgress.expectedTotalBytes!
                                  : null,
                            ),
                          );
                        }
                      },
                      errorBuilder: (BuildContext context, Object exception,
                          StackTrace? stackTrace) {
                        return const Center(
                          child: Text('Failed to load image'),
                        );
                      },
                    ),
                  ),
                )
              ],
            ),
          );
        });
  }
}

Icon getLevelIcon(String levelString) {
  switch (levelString) {
    case 'Emergency':
      return const Icon(Icons.warning,
          color: Colors.red); // or any other emergency icon
    case 'High':
      return const Icon(Icons.error,
          color: Colors.redAccent); // or any other high-level icon
    case 'Medium':
      return const Icon(Icons.warning_amber,
          color: Colors.yellow); // or any other medium-level icon
    case 'Low':
      return const Icon(Icons.info,
          color: Colors.green); // or any other low-level icon
    case 'Resolved':
      return const Icon(Icons.check, color: Colors.black);
    default:
      return const Icon(Icons.info, color: Colors.black); // Default icon
  }
}

/*import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/core/common/app/providers/user_provider.dart';
import 'package:guardian_view/src/alerts/domain/entities/alert_entity.dart';
import 'package:guardian_view/src/alerts/presention/cubit/alert_cubit.dart';
import 'package:guardian_view/src/video/presention/widgets/show_video.dart';
import 'package:video_player/video_player.dart';
import '../cubit/alert_state.dart';

class AlertListPage extends StatefulWidget {
  const AlertListPage({super.key});

  @override
  State<AlertListPage> createState() => _AlertListPageState();
}

class _AlertListPageState extends State<AlertListPage>
    with WidgetsBindingObserver {
  final int batchSize = 1;
  int loadedAlertsCount = 1;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    debugPrint('initilize');
  }

  @override
  void dispose() {
    debugPrint('disposed');
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
    debugPrint('disposed');
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.detached) {
      debugPrint('found it !!!');
    }
    if (state == AppLifecycleState.hidden) {
      debugPrint('found it2222 !!!');
    }
  }

  int compareAlertLevels(String level1, String level2) {
    final priorityOrder = {
      'emergency': 0,
      'high': 1,
      'medium': 2,
      'low': 3,
      'resolved': 4
    };

    final priority1 =
        priorityOrder[level1] ?? 999; // Default to lowest priority
    final priority2 =
        priorityOrder[level2] ?? 999; // Default to lowest priority

    return priority1.compareTo(priority2);
  }

  @override
  Widget build(BuildContext context) {
    context.read<AlertCubit>().resumeSubscription();
    bool? isAdmin = context.read<UserProvider>().user?.isAdmin;
    return Scaffold(
      appBar: AppBar(
        title: Text('Weapon Detection Alerts'),
      ),
      body: BlocBuilder<AlertCubit, AlertState>(
        builder: (context, state) {
          if (state is AlertStateLoaded && state.alertsList.isEmpty) {
            return const Center(
              child: Text('Empty !', style: TextStyle(color: Colors.black)),
            );
          }
          if (state is AlertStateLoaded) {
            final alerts = state.alertsList;
            alerts.sort((a, b) => compareAlertLevels(a.severity, b.severity));
            return Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: loadedAlertsCount,
                    itemBuilder: (context, index) {
                      final alert = alerts[index];
                      if (isAdmin!) {
                        return AlertCard(alert: alert);
                      }
                      if (!isAdmin &&
                          alert.isConfirmed &&
                          alert.severity != 'resolved') {
                        // If user is not admin, show only confirmed alerts
                        return AlertCard(alert: alert);
                      }
                      return const SizedBox
                          .shrink(); // Skip building other alerts
                    },
                  ),
                ),
                if (loadedAlertsCount < alerts.length) ...[
                  Row(
                    children: [
                      ElevatedButton(
                        onPressed: loadMoreAlerts,
                        child: const Text('Load More'),
                      ),
                      ElevatedButton(
                        onPressed: () => loadAllAlerts(state),
                        child: const Text('Load All'),
                      ),
                    ],
                  )
                ]
              ],
            );
          } else if (state is AlertStateError) {
            return Center(
              child: Text('Error: ${state.message}'),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }

  void loadMoreAlerts() {
    setState(() {
      loadedAlertsCount = loadedAlertsCount + batchSize;
    });
  }

  void loadAllAlerts(AlertStateLoaded state) {
    setState(() {
      loadedAlertsCount = state.alertsList.length;
    });
  }
}

class AlertCard extends StatefulWidget {
  final Alert alert;

  const AlertCard({super.key, required this.alert});
  @override
  _AlertCardState createState() => _AlertCardState();
}

class _AlertCardState extends State<AlertCard> {
  VideoPlayerController? controller;

  bool isExpanded = false;

  void _initializeVideoPlayer() {
    if (widget.alert.videoUrl != null) {
      final videoUri = Uri.parse(widget.alert.videoUrl!);
      controller = VideoPlayerController.networkUrl(videoUri)
        ..addListener(() => setState(() {}))
        ..setLooping(true)
        ..initialize().then((_) => setState(() {}));
    }
  }

  void _disposeVideoPlayer() {
    if (widget.alert.videoUrl != null) {
      controller?.removeListener(() => setState(() {}));
      controller?.dispose();
      controller = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final icon = getLevelIcon(widget.alert.severity);
    bool? isAdmin = context.read<UserProvider>().user?.isAdmin;
    return Card(
      child: ExpansionTile(
        leading: icon, // Status Icon
        title: Text(
            'severity: ${widget.alert.severity}, AlertType: ${widget.alert.alertType}, Confidence: ${widget.alert.confidence}'), // Alert title
        subtitle: Text(
            'Source: ${widget.alert.source}, Location: ${widget.alert.location ?? 'unKnown'}, Time: ${widget.alert.timestamp}'), // Location & Time

        onExpansionChanged: (expanded) {
          setState(() {
            isExpanded = expanded;
            if (isExpanded) {
              _initializeVideoPlayer();
            } else {
              _disposeVideoPlayer();
            }
          });
        },
        children: <Widget>[
          Visibility(
            visible: isAdmin!,
            child: ElevatedButton.icon(
              onPressed: () {
                context
                    .read<AlertCubit>()
                    .updateAlertConfirmationStatus(widget.alert.id);
              },
              icon: Icon(
                widget.alert.isConfirmed
                    ? Icons.check_circle
                    : Icons.check_circle_outline,
                color: widget.alert.isConfirmed ? Colors.green : Colors.grey,
              ),
              label: const Text('Confirm Alert'),
            ),
          ),
          if (widget.alert.videoUrl != null) ...[
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: VideoPlayerWidget(controller: controller),
            ),
          ],
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Text('Description: ${widget.alert.description}',
                style: const TextStyle(fontSize: 16)),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
              width: double.infinity, // Adjust this as needed
              height: 200, // Adjust this as needed
              child: Image.network(
                widget.alert.imageUrl,
                fit: BoxFit.cover, // Adjust this as needed
                loadingBuilder: (BuildContext context, Widget child,
                    ImageChunkEvent? loadingProgress) {
                  if (loadingProgress == null) {
                    return child;
                  } else {
                    return Center(
                      child: CircularProgressIndicator(
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded /
                                loadingProgress.expectedTotalBytes!
                            : null,
                      ),
                    );
                  }
                },
                errorBuilder: (BuildContext context, Object exception,
                    StackTrace? stackTrace) {
                  return const Center(
                    child: Text('Failed to load image'),
                  );
                },
              ),
            ),
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    _disposeVideoPlayer();
    super.dispose();
  }
}

Icon getLevelIcon(String levelString) {
  switch (levelString) {
    case 'emergency':
      return const Icon(Icons.warning,
          color: Colors.red); // or any other emergency icon
    case 'high':
      return const Icon(Icons.error,
          color: Colors.redAccent); // or any other high-level icon
    case 'medium':
      return const Icon(Icons.warning_amber,
          color: Colors.yellow); // or any other medium-level icon
    case 'low':
      return const Icon(Icons.info,
          color: Colors.green); // or any other low-level icon
    case 'resolved':
      return const Icon(Icons.check, color: Colors.black);
    default:
      return const Icon(Icons.info, color: Colors.black); // Default icon
  }
}
*/
