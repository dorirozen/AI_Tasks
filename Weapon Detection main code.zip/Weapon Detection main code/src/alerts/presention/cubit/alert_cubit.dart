import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/src/alerts/domain/usercases/get_alerts_ui.dart';
import 'package:guardian_view/src/alerts/domain/usercases/update_resolved.dart';
import 'package:guardian_view/src/alerts/presention/cubit/alert_state.dart';
import 'package:rxdart/rxdart.dart';

import '../../domain/usercases/update_alert.dart';

class AlertCubit extends Cubit<AlertState> {
  AlertCubit(
      {required GetAlertsUS getAlertsUS,
      required UpdateAlertsUS updateAlertsUS,
      required UpdateAlertsUSResolved updateAlertsUSResolved})
      : _getAlertsUS = getAlertsUS,
        _updateAlertsUS = updateAlertsUS,
        _updateAlertsUSResolved = updateAlertsUSResolved,
        super(const AlertStateInitial()) {
    _alertsSubscription?.cancel();
    getAlerts();
  }
  final GetAlertsUS _getAlertsUS;
  final UpdateAlertsUS _updateAlertsUS;
  final UpdateAlertsUSResolved _updateAlertsUSResolved;
  StreamSubscription? _alertsSubscription;
  bool _isStreamInitialized = false;

  void getAlerts() async {
    emit(const AlertStateLoading());
    final res = await _getAlertsUS();
    res.fold(
      (failure) => emit(AlertStateError(message: failure.errorMessage)),
      (alertsStream) {
        _alertsSubscription?.cancel(); // Cancel any existing subscription
        _alertsSubscription =
            alertsStream.debounceTime(const Duration(seconds: 3)).listen(
          //cancelOnError: false,
          (alerts) {
            emit(AlertStateLoaded(
                alertsList: alerts)); // Emit loaded state with list of alerts
          },
          onError: (error) {
            emit(
                AlertStateError(message: error.toString())); // Emit error state
          },
        );
        _isStreamInitialized = true;
      },
    );
  }

  // void updateAlertConfirmationStatus(String alertId) async {
  //   emit(const AlertStateLoading());
  //   final result = await _updateAlertsUS(alertId);
  //   result.fold(
  //       (failure) => emit(AlertStateError(message: failure.errorMessage)),
  //       (_) => emit(
  //           state)); // Emitting the current state triggers UI refresh with updated data
  // }
  void updateAlertConfirmationStatus(String alertId) async {
    if (isClosed) {
      debugPrint('AlertCubit is closed. Cannot update alert.');
      return;
    }

    try {
      emitSafe(AlertStateLoading());

      final result = await _updateAlertsUS(alertId);
      if (isClosed) return;

      result.fold(
        (failure) {
          debugPrint('Error updating alert: ${failure.errorMessage}');
          emitSafe(AlertStateError(message: failure.errorMessage));
        },
        (_) {
          debugPrint('Alert updated successfully');
          if (state is AlertStateLoaded) {
            final currentAlerts = (state as AlertStateLoaded).alertsList;
            final updatedAlerts = currentAlerts.map((alert) {
              if (alert.id == alertId) {
                return alert.copyWith(isConfirmed: true);
              }
              return alert;
            }).toList();
            emitSafe(AlertStateLoaded(alertsList: updatedAlerts));
          } else {
            getAlerts();
          }
        },
      );
    } catch (e, stackTrace) {
      debugPrint('Unexpected error in updateAlertConfirmationStatus: $e');
      debugPrint('Stack trace: $stackTrace');
      emitSafe(AlertStateError(message: 'Unexpected error: $e'));
    }
  }

  void updateAlertResolvedStatus(String alertId) async {
    if (isClosed) {
      debugPrint('AlertCubit is closed. Cannot update alert.');
      return;
    }

    try {
      emitSafe(AlertStateLoading());

      final result = await _updateAlertsUSResolved(alertId);
      if (isClosed) return;

      result.fold(
        (failure) {
          debugPrint('Error updating Resolved alert: ${failure.errorMessage}');
          emitSafe(AlertStateError(message: failure.errorMessage));
        },
        (_) {
          debugPrint('Alert severity status "resolved" updated successfully');
          if (state is AlertStateLoaded) {
            final currentAlerts = (state as AlertStateLoaded).alertsList;
            final updatedAlerts = currentAlerts.map((alert) {
              if (alert.id == alertId) {
                return alert.copyWith(severity: 'Resolved');
              }
              return alert;
            }).toList();
            emitSafe(AlertStateLoaded(alertsList: updatedAlerts));
          } else {
            getAlerts();
          }
        },
      );
    } catch (e, stackTrace) {
      debugPrint('Unexpected error in updateAlertConfirmationStatus: $e');
      debugPrint('Stack trace: $stackTrace');
      emitSafe(AlertStateError(message: 'Unexpected error: $e'));
    }
  }

  void emitSafe(AlertState state) {
    if (!isClosed) {
      emit(state);
    } else {
      debugPrint('Attempted to emit on a closed AlertCubit');
    }
  }

// Method to check if the stream is initialized
  bool checkStreamInitialized() {
    debugPrint('stream checked if initilized from cubit');
    return _isStreamInitialized;
  }

  // Method to pause the subscription
  void pauseSubscription() {
    debugPrint('app paused from cubit');
    if (_isStreamInitialized && _alertsSubscription != null) {
      _alertsSubscription?.pause();
    }
  }

  // Method to resume the subscription
  void resumeSubscription() {
    debugPrint('app resumed from cubit');
    if (_isStreamInitialized && _alertsSubscription != null) {
      _alertsSubscription?.resume();
    }
  }

  void resetState() {
    _alertsSubscription?.cancel();
    _isStreamInitialized = false;
    emit(const AlertStateInitial());
  }

  // Override close to cancel the subscription and update the flag
  @override
  Future<void> close() {
    debugPrint('alert disposed from cubit');
    _isStreamInitialized = false;
    _alertsSubscription?.cancel();
    return super.close();
  }
}
