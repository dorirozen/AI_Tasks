import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:guardian_view/core/error/exceptions.dart';
import 'package:guardian_view/src/alerts/data/models/alert_model.dart';

import '../../../../core/typedefs/typedef.dart';

abstract class DataSourceAlert {
  const DataSourceAlert();
  Stream<List<AlertModel>> getAlerts();
  void updateAlertConfirmationStatus(String id);
  void updateAlertResolvedStatus(String id);
}

class DataSourceAlertMyImpl implements DataSourceAlert {
  final FirebaseFirestore _firestore;
  final FirebaseStorage _storage;

  const DataSourceAlertMyImpl(
      {required FirebaseFirestore firestore, required FirebaseStorage storage})
      : _firestore = firestore,
        _storage = storage;

  @override
  Stream<List<AlertModel>> getAlerts() {
    try {
      return _firestore
          .collection('alerts')
          .snapshots()
          .asyncMap((snapshot) async {
        final alerts = await Future.wait(snapshot.docs.map((doc) async {
          final alertData = doc.data();
          // final videoUrlPath = alertData['videoUrl'];
          //
          // final videoUrl =
          //     await _storage.ref().child(videoUrlPath).getDownloadURL();
          final imageUrlPath = alertData['imageUrl'];
          final imageUrl =
              await _storage.ref().child(imageUrlPath).getDownloadURL();
          // original
          //     return AlertModel.fromMap(
          //       alertData,
          //       videoUrl: videoUrl,
          //       imageUrl: imageUrl,
          //     );
          //   }).toList());
          //   return alerts;
          // });
          return AlertModel.fromMap(
            alertData,
            imageUrl: imageUrl,
          );
        }).toList());
        return alerts;
      });
    } catch (e) {
      throw const ServerException(
          message: 'cannot achieve the list of alerts', statusCode: '500');
    }
  }

  @override
  Future<void> updateAlertConfirmationStatus(String id) async {
    try {
      final QuerySnapshot querySnapshot = await _firestore
          .collection('alerts')
          .where('id', isEqualTo: id)
          .limit(1)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        final DocumentSnapshot alertDocSnapshot = querySnapshot.docs.first;
        final alertData = alertDocSnapshot.data() as DataMap;

        final updatedIsConfirmed = !(alertData['isConfirmed'] as bool);
        await alertDocSnapshot.reference
            .update({'isConfirmed': updatedIsConfirmed});
      } else {
        throw const ServerException(
          message: 'Alert document not found',
          statusCode: '404',
        );
      }
    } catch (e) {
      throw const ServerException(
        message: 'Failed to update alert confirmation status',
        statusCode: '500',
      );
    }
  }

  @override
  Future<void> updateAlertResolvedStatus(String id) async {
    try {
      final QuerySnapshot querySnapshot = await _firestore
          .collection('alerts')
          .where('id', isEqualTo: id)
          .limit(1)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        final DocumentSnapshot alertDocSnapshot = querySnapshot.docs.first;
        await alertDocSnapshot.reference.update({'severity': "Resolved"});
      } else {
        throw const ServerException(
          message: 'Alert document not found',
          statusCode: '404',
        );
      }
    } catch (e) {
      throw const ServerException(
        message: 'Failed to update alert confirmation status',
        statusCode: '500',
      );
    }
  }
}
/*

@override
  Future<void> updateAlertConfirmationStatus(String id) async {
    try {
      final alertDocRef = _firestore.collection('alerts').doc(id);

      // Get the current data of the alert
      final alertDocSnapshot = await alertDocRef.get();
      final alertData = alertDocSnapshot.data() as DataMap;

      // Update the isConfirmed status to its opposite value
      final updatedIsConfirmed = !(alertData['isConfirmed'] as bool);

      // Update the document in Firebase Firestore
      await alertDocRef.update({'isConfirmed': updatedIsConfirmed});
    } catch (e) {
      throw const ServerException(
        message: 'Failed to update alert confirmation status',
        statusCode: '500',
      );
    }
  }
}


  @override
  Stream<List<AlertModel>> getAlerts() {
    try {
      return _firestore
          .collection('alerts')
          .snapshots()
          .map((snapshot) => snapshot.docs
              .map((doc) => AlertModel.fromMap(
                    doc.data(),
                  ))
              .toList());
    } catch (e) {
      throw const ServerException(
          message: 'cannot achieve the list of alerts', statusCode: '500');
    }
  }
}
 */
