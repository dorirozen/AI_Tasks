import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/alerts/domain/entities/alert_entity.dart';

class AlertModel extends Alert {
  const AlertModel(
      {required super.id,
      required super.timestamp,
      required super.severity,
      required super.description,
      required super.confidence,
      required super.isConfirmed,
      required super.alertType,
      required super.source,
      required super.imageUrl,
      super.location,
      super.latitude,
      super.longitude,
      super.videoUrl});

  DataMap toMap() {
    return {
      'alertType': alertType,
      'source': source,
      'description': description,
      'videoUrl': videoUrl,
      'imageUrl': imageUrl,
      'id': id,
      'severity': severity,
      'location': location,
      'longitude': longitude,
      'latitude': latitude,
      'confidence': confidence,
      'timestamp': FieldValue.serverTimestamp(),
      'isConfirmed': isConfirmed,
    };
  }

  AlertModel.fromMap(DataMap map,
      // {required String videoUrl, required String imageUrl})
      {required String imageUrl})
      : super(
          alertType: map['alertType'] as String,
          source: map['source'] as String,
          description: map['description'] as String,
          videoUrl: map['videoUrl'] as String?,
          imageUrl: imageUrl,
          id: map['id'] as String,
          severity: map['severity'] as String,
          location: map['location'] as String?,
          latitude: map['latitude'] as double?,
          longitude: map['longitude'] as double?,
          confidence: (map['confidence'] as num).toDouble(),
          timestamp: (map['timestamp'] as Timestamp).toDate(),
          isConfirmed: map['isConfirmed'] as bool,
        );
}
