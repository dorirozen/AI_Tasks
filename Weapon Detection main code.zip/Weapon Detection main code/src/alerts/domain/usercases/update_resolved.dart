import '../../../../core/common/usecases/usecase.dart';
import '../../../../core/typedefs/typedef.dart';
import '../repo_alert/repo_alert.dart';

class UpdateAlertsUSResolved implements UsecaseWithParams<void, String> {
  final AlertRepo _alertRepo;
  const UpdateAlertsUSResolved(this._alertRepo);

  @override
  ResultVoid call(String id) => _alertRepo.updateAlertsUSResolved(id);
}
