import 'package:equatable/equatable.dart';

/// this feature will need to get list of alerts. and so upload an alert.(from another phone).

class Alert extends Equatable {
  final String alertType;
  final String source;
  final String description;
  final String? videoUrl;
  final String imageUrl;
  final String id;
  final String severity;
  final String? location;
  final double? latitude;
  final double? longitude;
  final num confidence;
  final DateTime timestamp;
  final bool isConfirmed;

  const Alert({
    required this.id,
    required this.timestamp,
    required this.severity,
    required this.description,
    required this.confidence,
    required this.isConfirmed,
    required this.alertType,
    required this.source,
    required this.imageUrl,
    this.location,
    this.latitude,
    this.longitude,
    this.videoUrl,
  });

  @override
  List<Object?> get props => [id, timestamp, severity, isConfirmed];

  @override
  String toString() {
    return 'Alert{alertType: $alertType,location:$location, source: $source, description: $description, videoUrl: $videoUrl, imageUrl: $imageUrl, id: $id, severity: $severity, latitude: $latitude, longitude: $longitude, confidence: $confidence, timestamp: $timestamp, isConfirmed: $isConfirmed}';
  }

  Alert copyWith({
    String? alertType,
    String? source,
    String? description,
    String? videoUrl,
    String? imageUrl,
    String? id,
    String? severity,
    double? latitude,
    double? longitude,
    String? location,
    num? confidence,
    DateTime? timestamp,
    bool? isConfirmed,
  }) {
    return Alert(
      alertType: alertType ?? this.alertType,
      source: source ?? this.source,
      description: description ?? this.description,
      videoUrl: videoUrl ?? this.videoUrl,
      imageUrl: imageUrl ?? this.imageUrl,
      id: id ?? this.id,
      severity: severity ?? this.severity,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      confidence: confidence ?? this.confidence,
      location: location ?? this.location,
      timestamp: timestamp ?? this.timestamp,
      isConfirmed: isConfirmed ?? this.isConfirmed,
    );
  }
}

/*

class U {
  const U({required this.id, required this.name, required this.city});
  final String name;
  final String id;
  final String city;
  static U fromJson(json) => U(
        name: json['name'],
        id: json['id'],
        city: json['city'],
      );
}
 */
