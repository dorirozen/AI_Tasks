import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/video/domain/entity/video_entity.dart';

class VideoDataModel extends VideoData {
  const VideoDataModel({required super.timestamp, super.processed, super.URL});

  DataMap toMap() {
    return {
      'processed': processed,
      'URL': URL,
      'timestamp': FieldValue.serverTimestamp(),
    };
  }

  VideoDataModel.fromMap(DataMap map)
      : super(
          timestamp: (map['timestamp'] as Timestamp).toDate(),
          processed: map['processed'] as bool,
          URL: map['URL'] as String,
        );

  VideoDataModel copyWith({
    DateTime? timestamp,
    String? URL,
    bool? processed,
  }) {
    return VideoDataModel(
      timestamp: timestamp ?? this.timestamp,
      processed: processed ?? this.processed,
      URL: URL ?? this.URL,
    );
  }
}
