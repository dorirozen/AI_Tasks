import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/src/video/domain/entity/file_entity.dart';
import 'package:guardian_view/src/video/domain/entity/video_entity.dart';
import 'package:guardian_view/src/video/presention/cubit/video_cubit.dart';
import 'package:guardian_view/src/video/presention/cubit/video_state.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../core/resources/fonts.dart';
import '../cubit/post_upload_cubit.dart';

class UploadVideo extends StatefulWidget {
  static const routeName = '/uploadVideo';
  const UploadVideo({Key? key}) : super(key: key);

  @override
  State<UploadVideo> createState() => _UploadVideoState();
}

class _UploadVideoState extends State<UploadVideo> {
  File? selectedVideo;
  Uint8List? webImage;
  bool isUploading = false;
  double perc = 0;
  VideoFile? fileData;
  bool videoUploaded = false;
  final TextEditingController _fileNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                width: 230,
                child: Text(
                  'Guardian View',
                  style: TextStyle(
                    color: Colors.black54,
                    fontFamily: Fonts.beautiful_people,
                    fontWeight: FontWeight.w900,
                    fontSize: 25,
                    shadows: [
                      Shadow(
                        offset: Offset(0, 3),
                        blurRadius: 5,
                        color: Colors.white12,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(width: 4),
              SizedBox(
                child: Image.asset(
                  'assets/images/projectLogo.png',
                  fit: BoxFit.contain,
                  width: 40,
                  height: 40,
                ),
              ),
            ],
          ),
        ),
      ),
      body: BlocConsumer<VideoCubit, VideoState>(
        listener: (context, state) {
          if (state is VideoStateAdded) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Video uploaded successfully!')),
            );
            setState(() {
              isUploading = false;
              selectedVideo = null; // Reset the selectedVideo reference
              videoUploaded = true;
            });
            // Correctly accessing PostUploadCubit
            try {
              context.read<PostUploadCubit>().triggerUpload(state.taskSnapshot);
            } catch (error) {
              debugPrint("Failed to trigger upload: $error");
            }
            //context.read<VideoCubit>().close();// deleted to allow multipul uploads
          }

          if (state is VideoStateError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message)),
            );
            context.read<VideoCubit>().close();
            setState(() {
              isUploading = false;
            });
            debugPrint('state is VideoStateError');
          }
          if (state is VideoStateAdding) {
            setState(() {
              perc = state.progress.toDouble();
            });
          }
        },
        builder: (context, state) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Card(
              elevation: 14, // Adds a drop shadow effect
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8), // Rounds the corners
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // TextField(
                    //   controller: _fileNameController,
                    //   decoration: const InputDecoration(
                    //     labelText: 'Enter file name',
                    //   ),
                    // ),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: TextField(
                        controller: _fileNameController,
                        decoration: InputDecoration(
                          labelText: 'Enter file name',
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 16,
                          ),
                          prefixIcon: const Icon(
                            Icons.insert_drive_file,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    if (state is VideoStateAdding)
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: LinearProgressIndicator(
                          value: perc / 100,
                          backgroundColor: Colors.grey,
                          valueColor:
                              const AlwaysStoppedAnimation<Color>(Colors.blue),
                        ),
                      ),
                    const SizedBox(height: 16.0),
                    OutlinedButton.icon(
                      onPressed: () async {
                        await selectVideo();
                        String fileName = _fileNameController.text.isNotEmpty
                            ? '${_fileNameController.text}.mp4'
                            : 'uploadedVideo.mp4';
                        debugPrint('File Name: $fileName');
                      },
                      icon: const Icon(Icons.video_library),
                      label: const Text('Select Video'),
                    ),
                    const SizedBox(height: 16.0),
                    OutlinedButton.icon(
                      onPressed: (!videoUploaded &&
                              (selectedVideo != null || webImage != null) &&
                              !isUploading)
                          ? () => uploadVideo(context)
                          : null,
                      icon: const Icon(Icons.upload),
                      label: const Text('Upload Video'),
                    ),
                    const SizedBox(height: 16.0),
                    OutlinedButton.icon(
                      onPressed: () {
                        context.read<VideoCubit>().close();
                        debugPrint('stream closed from button');
                      },
                      icon: const Icon(Icons.cancel),
                      label: const Text('Cancel Stream'),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> selectImage() async {
    if (!kIsWeb) {
      final ImagePicker picker = ImagePicker();
      XFile? image = await picker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        var selected = File(image.path);
        setState(() {
          selectedVideo = selected;
          webImage = null;
          isUploading = false;
        });
      } else {
        debugPrint('error picking image');
      }
    } else if (kIsWeb) {
      final ImagePicker picker = ImagePicker();
      XFile? image = await picker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        var f = await image.readAsBytes();
        setState(() {
          webImage = f;
          selectedVideo = null;
          isUploading = false;
        });
      } else {
        debugPrint('error picking image');
      }
    } else {
      debugPrint('something went wrong');
    }
  }

  Future<void> selectVideo() async {
    if (!kIsWeb) {
      // Pick a video file using FilePicker
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.video,
      );

      if (result != null && result.files.single.path != null) {
        var selected = File(result.files.single.path!);
        setState(() {
          selectedVideo = selected;
          webImage = null;
          isUploading = false;
          videoUploaded =
              false; // Set videoUploaded to false when a new video is selected
        });
      } else {
        debugPrint('Error picking video');
      }
    } else if (kIsWeb) {
      // Pick a video file using FilePicker
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.video,
      );

      if (result != null) {
        var f = result.files.single.bytes;
        setState(() {
          webImage = f;
          selectedVideo = null;
          isUploading = false;
          videoUploaded =
              false; // Set videoUploaded to false when a new video is selected
        });
      } else {
        debugPrint('Error picking video');
      }
    } else {
      debugPrint('Something went wrong');
    }
  }

  void uploadVideo(BuildContext context) {
    String fileName = _fileNameController.text.isNotEmpty
        ? '${_fileNameController.text}.mp4'
        : 'uploadedVideo.mp4';
    final videoData = VideoData(
      timestamp: DateTime.now(),
      URL: fileName,
      processed: false,
    );

    if (!kIsWeb && selectedVideo != null) {
      setState(() {
        fileData = VideoFile(file: selectedVideo);
      });
    } else if (kIsWeb) {
      setState(() {
        fileData = VideoFile(bytes: webImage);
      });
    }
    if (fileData != null) {
      if (selectedVideo != null || webImage != null) {
        setState(() {
          isUploading = true; // Set the flag when upload starts
          videoUploaded =
              true; // Set videoUploaded to true when the upload starts
        });
        context.read<VideoCubit>().addVideoDataUs(videoData, fileData!);
      }
    }
  }
}
