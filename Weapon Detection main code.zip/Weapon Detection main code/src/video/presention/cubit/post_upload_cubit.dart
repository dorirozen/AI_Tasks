import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/src/video/domain/usecases/post_upload_us.dart';
import 'package:guardian_view/src/video/presention/cubit/post_upload_state.dart';


class PostUploadCubit extends Cubit<PostUploadState> {
  final PostUploadUS _postUploadUS;

  PostUploadCubit({
    required PostUploadUS postUploadUS,
  })  : _postUploadUS = postUploadUS,
        super(const PostUploadInitial());

  Future<void> triggerUpload(dynamic taskSnapshot) async {
    debugPrint("Triggering upload in PostUploadCubit");
    try {
      await _postUploadUS(PostUploadData(
        taskSnapshot: taskSnapshot,
      ));
      debugPrint("Upload completed successfully");
      emit(const PostUploadStateSuccess());
    } catch (error) {
      debugPrint("Upload failed: $error");
      emit(PostUploadStateError(message: error.toString()));
    }
  }
}

/*
class PostUploadCubit extends Cubit<PostUploadState> {
  final VideoCubit _videoCubit;
  late StreamSubscription videoCubitSubscription;
  final PostUploadUS _postUploadUS;
  PostUploadCubit(
      {required VideoCubit videoCubit, required PostUploadUS postUploadUS})
      : _postUploadUS = postUploadUS,
        _videoCubit = videoCubit,
        super(const PostUploadInitial()) {
    debugPrint("PostUploadCubit initilzied");
    videoCubitSubscription = _videoCubit.stream.listen((videoState) async {
      debugPrint("checkkkkkkkkkkkkkkkk");
      if (videoState is VideoStateAdded) {
        debugPrint("i am here (PostUploadCubit)");
        await _postUploadUS(PostUploadData(
            videoData: videoState.videoData,
            taskSnapshot: videoState.taskSnapshot));
      } else {
        debugPrint("Other video state received: $videoState");
      }
    });
  }

  @override
  Future<void> close() {
    videoCubitSubscription.cancel();
    return super.close();
  }
}
*/
