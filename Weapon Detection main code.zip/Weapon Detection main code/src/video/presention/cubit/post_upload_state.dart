import 'package:equatable/equatable.dart';

abstract class PostUploadState extends Equatable {
  const PostUploadState();
  @override
  List<Object?> get props => [];
}

class PostUploadInitial extends PostUploadState {
  const PostUploadInitial();
}

class PostUploadStateError extends PostUploadState {
  const PostUploadStateError({required this.message});
  final String message;
}

class PostUploadStateSuccess extends PostUploadState {
  const PostUploadStateSuccess();
  @override
  List<Object?> get props => [];
}
