import 'package:equatable/equatable.dart';

class VideoData extends Equatable {
  final bool processed;
  final String URL;
  final DateTime timestamp;

  const VideoData({required this.timestamp, this.processed = false, this.URL = ''});

  @override
  List<Object?> get props => [processed, URL];

  @override
  String toString() {
    return 'processed:$processed, URL: $URL}';
  }

  VideoData.empty()
      : this(
          timestamp: DateTime.now(),
          URL: '',
          processed: false,
        );
}
