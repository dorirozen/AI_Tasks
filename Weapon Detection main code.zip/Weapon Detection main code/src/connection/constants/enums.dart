enum ConnectionType {
  wifi,
  mobile,
  other,
  vpn,
  ethernet,
  none,
}
