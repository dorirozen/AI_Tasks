import 'package:equatable/equatable.dart';
import 'package:guardian_view/core/resources/media_res.dart';

class ContentPage extends Equatable {
  const ContentPage(
      {required this.image, required this.title, required this.des});
  final String image;
  final String title;
  final String des;

  const ContentPage.first()
      : this(
            image: MediaRes.logoPage,
            des:
                'Our primary objective in this project is to reduce the response time of'
                ' emergency services, including police and ambulance.'
                ' Instead of relying on reports from citizens in the field,'
                ' the forces will receive alerts directly from the system,'
                ' thereby saving valuable, life-saving time',
            title: 'Welcome to our Guardian View final project');

  const ContentPage.second()
      : this(
            image: MediaRes.gunImage,
            des:
                'Our cutting-edge app utilizes advanced AI algorithms to detect weapons in real-time video feeds, providing an extra layer of security for your peace of mind. Stay vigilant and proactive with our innovative solution.',
            title: 'Enhance Security with AI-Powered Weapon Detection');

  const ContentPage.third()
      : this(
            image: MediaRes.notiImage,
            des:
                'In the event of a detected weapon, our app immediately sends alerts to designated personnel or authorities, enabling swift and appropriate action. Stay ahead of potential threats with our real-time notification system, ensuring a rapid response to any identified risks.',
            title: 'Instant Alerts, Rapid Response');

  @override
  List<Object?> get props => [image, title, des];
}
