import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/core/extentions/context_extensions.dart';
import 'package:guardian_view/core/resources/fonts.dart';
import 'package:guardian_view/src/on_boarding/domain/entites/content_page.dart';
import 'package:guardian_view/src/on_boarding/presention/cubit/on_boarding_cubit.dart';

import '../../../../core/resources/colors.dart';

class OnBoardingBody extends StatelessWidget {
  const OnBoardingBody({required this.pageContent, Key? key}) : super(key: key);
  final ContentPage pageContent;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(20).copyWith(bottom: 0),
          child: Column(
            children: [
              SizedBox(height: context.height * .02),
              title(pageContent.title),
              SizedBox(height: context.height * .02),
              desc(pageContent.des),
              SizedBox(height: context.height * .05),
              Image.asset(
                pageContent.image,
                height: context.height * .4,
              ),
              SizedBox(
                height: context.height * .03,
              ),
              buttonStart(context),
            ],
          ),
        )
      ],
    );
  }
}

Widget desc(String des) {
  return Text(
    des,
    textAlign: TextAlign.start,
    style: const TextStyle(
      color: Color(0xDDDADEDD),
      fontSize: 20,
      fontFamily: Fonts.agbalumo_Font,
      fontWeight: FontWeight.bold,
    ),
  );
}

Widget title(String title) {
  return Text(
    overflow: TextOverflow.visible,
    title,
    textAlign: TextAlign.center,
    style: const TextStyle(
      color: Color(0xDDD4C1F6),
      fontFamily: Fonts.beautiful_people,
      fontSize: 25,
      fontWeight: FontWeight.bold,
    ),
  );
}

Widget buttonStart(BuildContext context) {
  return ElevatedButton(
    style: ElevatedButton.styleFrom(
      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 17),
      backgroundColor: MyColors.schemeColor,
      foregroundColor: Colors.white,
    ),
    onPressed: () {
      context.read<OnBoardingCubit>().cacheFirstTimer();
    },
    child: const Text(
      'Get started',
      style: TextStyle(fontFamily: Fonts.agbalumo, fontWeight: FontWeight.bold),
    ),
  );
}
