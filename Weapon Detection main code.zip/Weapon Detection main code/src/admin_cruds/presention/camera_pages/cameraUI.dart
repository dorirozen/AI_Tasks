// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:guardian_view/src/admin_cruds/presention/camera_pages/sub_pages_cameras/addCameraAdmin.dart';
//
// import '../../../../core/common/widgets/nested_back_button.dart';
//
// class AdminCameraPage extends StatefulWidget {
//   @override
//   State<AdminCameraPage> createState() => _AdminCameraPageState();
// }
//
// class _AdminCameraPageState extends State<AdminCameraPage> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: const NestedBackButton(),
//         title: Text('Users Settings'),
//       ),
//       body: BlocBuilder<AuthBloc, AuthState>(
//         builder: (context, state) {
//           if (state is AuthStateGetUsers && state.users.isEmpty) {
//             return Center(
//               child: Text('Empty !', style: TextStyle(color: Colors.black)),
//             );
//           }
//           if (state is AuthStateGetUsers) {
//             final users = state.users;
//             return Column(
//               children: [
//                 Padding(
//                   padding: const EdgeInsets.all(8.0),
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.of(context).push(
//                         MaterialPageRoute(
//                           builder: (context) => BlocProvider.value(
//                             value: sl<AuthBloc>(),
//                             // child: AdminAddUserScreen(),
//                             child: AdminAddCameraScreen(),
//                           ),
//                         ),
//                       );
//                     },
//                     child: Text(''
//                         // 'Add $users || camera'
//                         ), // -> send to another modalsheet using authbloc or bloc for cameras..
//                   ),
//                 ),
//                 Expanded(
//                   child: ListView.builder(
//                     itemCount: users.length,
//                     itemBuilder: (context, index) {
//                       final user = users[index];
//                       return CameraCard(user: user);
//                     },
//                   ),
//                 ),
//               ],
//             );
//           } else if (state is AuthStateError) {
//             return Center(
//               child: Text('Error: ${state.message}'),
//             );
//           } else {
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           }
//         },
//       ),
//     );
//   }
// }
//
// class CameraCard extends StatefulWidget {
//   final Camera camera;
//
//   const CameraCard({super.key, required this.camera});
//   @override
//   _CameraCardState createState() => _CameraCardState();
// }
//
// class _CameraCardState extends State<CameraCard> {
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       child: ListTile(
//         title: Text('camera Name: ${widget.camera.fullName}'),
//         subtitle: Text('camera location: ${widget.camera.email}'),
//         trailing: Row(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             IconButton(
//               icon: Icon(Icons.edit),
//               onPressed: () {
//                 // Open a dialog or navigate to another screen to edit the item
//               },
//             ),
//             IconButton(
//               icon: Icon(Icons.delete),
//               onPressed: () {
//                 //Firetry().deleteItem(categoryTitle, categoryItem.id);
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
