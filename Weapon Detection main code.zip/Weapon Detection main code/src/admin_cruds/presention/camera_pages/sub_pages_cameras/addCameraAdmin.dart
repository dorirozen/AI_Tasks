// import 'package:flutter/material.dart';
//
// import '../../../../../core/common/widgets/gradient_background.dart';
// import '../../../../../core/common/widgets/nested_back_button.dart';
// import '../../../../../core/resources/fonts.dart';
// import '../../../../../core/resources/media_res.dart';
// import '../../../../../core/utils/core_utils.dart';
//
// class AdminAddCameraScreen extends StatefulWidget {
//   const AdminAddCameraScreen({Key? key}) : super(key: key);
//   @override
//   State<AdminAddCameraScreen> createState() => _AdminAddCameraScreenState();
// }
//
// class _AdminAddCameraScreenState extends State<AdminAddCameraScreen> {
//   final emailController = TextEditingController();
//   final fullNameController = TextEditingController();
//   final passwordController = TextEditingController();
//   final cityController = TextEditingController();
//   final phoneNumController = TextEditingController();
//   final confirmPasswordController = TextEditingController();
//   final formKey = GlobalKey<FormState>();
//
//   @override
//   void dispose() {
//     emailController.dispose();
//     phoneNumController.dispose();
//     cityController.dispose();
//     passwordController.dispose();
//     confirmPasswordController.dispose();
//     fullNameController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: const NestedBackButton(),
//       ),
//       backgroundColor: Colors.white,
//       body: BlocConsumer<AuthBloc, AuthState>(
//         listener: (_, state) {
//           if (state is AuthStateLoading) {
//             const CircularProgressIndicator();
//           }
//           if (state is AuthStateSignedUp) {
//             Navigator.pop(context);
//             //Future.delayed(const Duration(seconds: 1));
//             CoreUtils.showSnackBar(
//                 context, 'You have added a user successfully');
//           } else if (state is AuthStateError) {
//             CoreUtils.showSnackBar(context, state.message);
//           }
//         },
//         builder: (context, state) {
//           return GradientBackGround(
//               image: MediaRes.image3,
//               child: SafeArea(
//                 child: Center(
//                   child: ListView(
//                     shrinkWrap: true,
//                     padding: const EdgeInsets.symmetric(horizontal: 20),
//                     children: [
//                       const Text(
//                         'Fill the user info',
//                         style: TextStyle(
//                           fontFamily: Fonts.beautiful_people,
//                           fontWeight: FontWeight.w700,
//                           fontSize: 32,
//                         ),
//                       ),
//                       const SizedBox(
//                         height: 10,
//                       ),
//                       const Text(
//                         'sign Up for an account',
//                         style: TextStyle(
//                           fontSize: 14,
//                         ),
//                       ),
//                       const SizedBox(
//                         height: 10,
//                       ),
//                       SignUpForm(
//                           emailController: emailController,
//                           passwordController: passwordController,
//                           fullNameController: fullNameController,
//                           phoneNumController: phoneNumController,
//                           cityController: cityController,
//                           confirmPasswordController: confirmPasswordController,
//                           formKey: formKey),
//                       const SizedBox(
//                         height: 10,
//                       ),
//                       state is AuthStateLoading
//                           ? const Center(child: CircularProgressIndicator())
//                           : RoundedButton(
//                               label: 'Add the user',
//                               buttonColor: MyColors.primaryColor,
//                               labelColor: Colors.white,
//                               onPressed: () {
//                                 FocusManager.instance.primaryFocus?.unfocus();
//                                 if (formKey.currentState!.validate()) {
//                                   context.read<AuthBloc>().add(
//                                         AuthEventSignUp(
//                                           email: emailController.text.trim(),
//                                           password:
//                                               passwordController.text.trim(),
//                                           name: fullNameController.text.trim(),
//                                           phoneNum:
//                                               phoneNumController.text.trim(),
//                                           city: cityController.text.trim(),
//                                         ),
//                                       );
//                                 }
//                               },
//                             ),
//                     ],
//                   ),
//                 ),
//               ));
//         },
//       ),
//     );
//   }
// }
