// import 'package:flutter/material.dart';
//
// import '../../../domain/entities/camera.dart';
//
// class EditCameraAdmin extends StatefulWidget {
//   final CameraCrud camera;
//   const EditCameraAdmin({Key? key, required this.camera}) : super(key: key);
//
//   @override
//   State<EditCameraAdmin> createState() => _EditCameraAdminState();
// }
//
// class _EditCameraAdminState extends State<EditCameraAdmin> {
//   final fullNameController = TextEditingController();
//   final emailController = TextEditingController();
//   final phoneNumController = TextEditingController();
//   final cityController = TextEditingController();
//
//   bool _listenersAdded = false;
//   // Listener functions will be defined later within the StatefulBuilder
//   late void Function() refreshFullName;
//   late void Function() refreshEmail;
//   late void Function() refreshPhoneNum;
//   late void Function() refreshCity;
//
//   bool get isCityChanged =>
//       widget.user.city.trim() != cityController.text.trim();
//   bool get isEmailChanged => emailController.text.trim().isNotEmpty;
//   bool get isFullNameChanged =>
//       widget.user.fullName.trim() != fullNameController.text.trim();
//   bool get isPhoneNumChanged =>
//       widget.user.phoneNum?.trim() != phoneNumController.text.trim();
//   bool get nothingChanged =>
//       !isFullNameChanged &&
//       !isCityChanged &&
//       !isEmailChanged &&
//       !isPhoneNumChanged;
//   @override
//   void initState() {
//     fullNameController.text = widget.user.fullName.trim();
//     phoneNumController.text = widget.user.phoneNum.trim();
//     cityController.text = widget.user.city.trim();
//     emailController.text = widget.user.email.trim();
//     super.initState();
//   }
//
//   @override
//   void dispose() {
//     if (_listenersAdded) {
//       fullNameController.removeListener(refreshFullName);
//       emailController.removeListener(refreshEmail);
//       phoneNumController.removeListener(refreshPhoneNum);
//       cityController.removeListener(refreshCity);
//     }
//     fullNameController.dispose();
//     emailController.dispose();
//     phoneNumController.dispose();
//     cityController.dispose();
//
//     super.dispose();
//   }
//
//   void _addListenersIfNeeded(Function refresh) {
//     if (!_listenersAdded) {
//       // Define listener functions using the refresh callback from StatefulBuilder
//       refreshFullName = () => refresh(() {});
//       refreshEmail = () => refresh(() {});
//       refreshPhoneNum = () => refresh(() {});
//       refreshCity = () => refresh(() {});
//
//       fullNameController.addListener(refreshFullName);
//       emailController.addListener(refreshEmail);
//       phoneNumController.addListener(refreshPhoneNum);
//       cityController.addListener(refreshCity);
//       _listenersAdded = true;
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return BlocConsumer<AuthBloc, AuthState>(
//       listener: (context, state) {
//         if (state is AuthStateLoading) {
//           const CircularProgressIndicator();
//         }
//         if (state is AuthStateEditedUser) {
//           Navigator.pop(context);
//
//           CoreUtils.showSnackBar(
//               context, 'User ${widget.user.fullName} updated successfully');
//         } else if (state is AuthStateError) {
//           CoreUtils.showSnackBar(context, state.message);
//         }
//       },
//       builder: (context, state) {
//         return Scaffold(
//           extendBodyBehindAppBar: true,
//           appBar: AppBar(
//             leading: const NestedBackButton(),
//             actions: [
//               TextButton(
//                 onPressed: () {
//                   if (nothingChanged) Navigator.pop(context); //context.pop();
//                   final bloc = context.read<AuthBloc>();
//
//                   if (isFullNameChanged) {
//                     bloc.add(
//                       AuthEventEditUser(
//                           userData: fullNameController.text.trim(),
//                           action: EditUserActionAdmin.displayName,
//                           user: widget.user),
//                     );
//                   }
//                   if (isEmailChanged) {
//                     bloc.add(
//                       AuthEventEditUser(
//                           userData: emailController.text.trim(),
//                           action: EditUserActionAdmin.email,
//                           user: widget.user),
//                     );
//                   }
//                   if (isPhoneNumChanged) {
//                     bloc.add(
//                       AuthEventEditUser(
//                           userData: phoneNumController.text.trim(),
//                           action: EditUserActionAdmin.phoneNum,
//                           user: widget.user),
//                     );
//                   }
//                   if (isCityChanged) {
//                     bloc.add(
//                       AuthEventEditUser(
//                           userData: cityController.text.trim(),
//                           action: EditUserActionAdmin.city,
//                           user: widget.user),
//                     );
//                   }
//                 },
//                 child: state is AuthStateLoading
//                     ? const Center(
//                         child: CircularProgressIndicator(),
//                       )
//                     : StatefulBuilder(builder: (_, refresh) {
//                         _addListenersIfNeeded(refresh);
//
//                         /// set the state and then nothingChanged will be with diff value
//                         return Text(
//                           'Done',
//                           style: TextStyle(
//                               fontWeight: FontWeight.w500,
//                               fontSize: 16,
//                               color: nothingChanged
//                                   ? Colors.grey
//                                   : Colors.blueAccent),
//                         );
//                       }),
//               ),
//             ],
//           ),
//           body: GradientBackGround(
//             image: MediaRes.image3,
//             child: ListView(
//               padding: const EdgeInsets.symmetric(horizontal: 20),
//               children: [
//                 const SizedBox(
//                   height: 180,
//                 ),
//                 EditUserAdminForm(
//                     fullNameController: fullNameController,
//                     emailController: emailController,
//                     phoneNumController: phoneNumController,
//                     cityController: cityController),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
