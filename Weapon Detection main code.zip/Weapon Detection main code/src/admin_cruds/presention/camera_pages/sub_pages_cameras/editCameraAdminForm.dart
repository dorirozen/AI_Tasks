// import 'package:flutter/material.dart';
// import 'package:guardian_view/core/extentions/context_extensions.dart';
// import 'package:guardian_view/src/profile/edit_profile_form_field.dart';
//
// class EditUserAdminForm extends StatelessWidget {
//   const EditUserAdminForm(
//       {Key? key,
//       required this.fullNameController,
//       required this.emailController,
//       required this.phoneNumController,
//       required this.cityController})
//       : super(key: key);
//
//   final TextEditingController fullNameController;
//   final TextEditingController cityController;
//   final TextEditingController emailController;
//   final TextEditingController phoneNumController;
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         EditProfileFormField(
//             fieldTitle: 'Full Name',
//             controller: fullNameController,
//             hintText: context.currentUser!.fullName),
//         EditProfileFormField(
//             fieldTitle: 'Email',
//             controller: emailController,
//             hintText: context.currentUser!.email),
//         EditProfileFormField(
//             fieldTitle: 'phone number',
//             controller: phoneNumController,
//             hintText: context.currentUser!.phoneNum),
//         EditProfileFormField(
//             fieldTitle: 'City',
//             controller: cityController,
//             hintText: context.currentUser!.city),
//       ],
//     );
//   }
// }
