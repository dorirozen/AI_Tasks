import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/common/widgets/gradient_background.dart';
import '../../../../../core/common/widgets/nested_back_button.dart';
import '../../../../../core/common/widgets/rounded_button.dart';
import '../../../../../core/resources/colors.dart';
import '../../../../../core/resources/fonts.dart';
import '../../../../../core/resources/media_res.dart';
import '../../../../../core/utils/core_utils.dart';
import '../../../../auth/presention/bloc/auth_bloc.dart';
import '../../../../auth/presention/bloc/auth_event.dart';
import '../../../../auth/presention/bloc/auth_state.dart';
import '../../../../auth/presention/widgets/sign_up_form.dart';

class AdminAddUserScreen extends StatefulWidget {
  const AdminAddUserScreen({Key? key}) : super(key: key);
  @override
  State<AdminAddUserScreen> createState() => _AdminAddUserScreenState();
}

class _AdminAddUserScreenState extends State<AdminAddUserScreen> {
  final emailController = TextEditingController();
  final fullNameController = TextEditingController();
  final passwordController = TextEditingController();
  final cityController = TextEditingController();
  final phoneNumController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    emailController.dispose();
    phoneNumController.dispose();
    cityController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    fullNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const NestedBackButton(),
      ),
      backgroundColor: Colors.white,
      body: BlocConsumer<AuthBloc, AuthState>(
        listener: (_, state) {
          if (state is AuthStateLoading) {
            const CircularProgressIndicator();
          }
          if (state is AuthStateSignedUp) {
            Navigator.pop(context);
            CoreUtils.showSnackBar(
                context, 'You have added a user successfully');
          } else if (state is AuthStateError) {
            CoreUtils.showSnackBar(context, state.message);
          }
        },
        builder: (context, state) {
          return GradientBackGround(
              image: MediaRes.addUserBackGround,
              darkenImage: true,
              child: SafeArea(
                child: Center(
                  child: ListView(
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    children: [
                      const Text(
                        'Fill the user info',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: Fonts.beautiful_people,
                          fontWeight: FontWeight.w700,
                          fontSize: 32,
                        ),
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      // const Text(
                      //   'sign Up for an account',
                      //   style: TextStyle(
                      //     fontSize: 14,
                      //   ),
                      // ),
                      const SizedBox(
                        height: 10,
                      ),
                      SignUpForm(
                          emailController: emailController,
                          passwordController: passwordController,
                          fullNameController: fullNameController,
                          phoneNumController: phoneNumController,
                          cityController: cityController,
                          confirmPasswordController: confirmPasswordController,
                          formKey: formKey),
                      const SizedBox(
                        height: 10,
                      ),
                      state is AuthStateLoading
                          ? const Center(child: CircularProgressIndicator())
                          : RoundedButton(
                              label: 'Add the user',
                              buttonColor: MyColors.primaryColor,
                              labelColor: Colors.white,
                              onPressed: () {
                                FocusManager.instance.primaryFocus?.unfocus();
                                if (formKey.currentState!.validate()) {
                                  context.read<AuthBloc>().add(
                                        AuthEventSignUp(
                                          email: emailController.text.trim(),
                                          password:
                                              passwordController.text.trim(),
                                          name: fullNameController.text.trim(),
                                          phoneNum:
                                              phoneNumController.text.trim(),
                                          city: cityController.text.trim(),
                                        ),
                                      );
                                }
                              },
                            ),
                    ],
                  ),
                ),
              ));
        },
      ),
    );
  }
}
