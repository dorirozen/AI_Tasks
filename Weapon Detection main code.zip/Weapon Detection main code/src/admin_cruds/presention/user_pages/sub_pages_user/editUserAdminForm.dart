import 'package:flutter/material.dart';
import 'package:guardian_view/core/extentions/context_extensions.dart';
import 'package:guardian_view/src/profile/edit_profile_form_field.dart';

class EditUserAdminForm extends StatelessWidget {
  const EditUserAdminForm(
      {Key? key,
      required this.fullNameController,
      required this.emailController,
      required this.phoneNumController,
      required this.cityController})
      : super(key: key);

  final TextEditingController fullNameController;
  final TextEditingController cityController;
  final TextEditingController emailController;
  final TextEditingController phoneNumController;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        EditProfileFormField(
            fieldTitle: 'Full Name',
            colorSelected: Colors.white,
            controller: fullNameController,
            hintText: context.currentUser!.fullName),
        EditProfileFormField(
            fieldTitle: 'Email',
            colorSelected: Colors.white,
            controller: emailController,
            hintText: context.currentUser!.email),
        EditProfileFormField(
            fieldTitle: 'phone number',
            colorSelected: Colors.white,
            controller: phoneNumController,
            hintText: context.currentUser!.phoneNum),
        EditProfileFormField(
            fieldTitle: 'City',
            colorSelected: Colors.white,
            controller: cityController,
            hintText: context.currentUser!.city),
      ],
    );
  }
}
