import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/src/admin_cruds/presention/user_pages/sub_pages_user/addUserAdmin.dart';
import 'package:guardian_view/src/admin_cruds/presention/user_pages/sub_pages_user/editUserAdmin.dart';
import 'package:guardian_view/src/auth/presention/bloc/auth_state.dart';

import '../../../../core/common/widgets/nested_back_button.dart';
import '../../../../core/services/getit/injection_container.main.dart';
import '../../../auth/domain/entites/local_user.dart';
import '../../../auth/presention/bloc/auth_bloc.dart';

class AdminUserPage extends StatefulWidget {
  const AdminUserPage({super.key});

  @override
  State<AdminUserPage> createState() => _AdminUserPageState();
}

class _AdminUserPageState extends State<AdminUserPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const NestedBackButton(),
        title: const Text('Users Settings'),
      ),
      body: BlocBuilder<AuthBloc, AuthState>(
        builder: (context, state) {
          if (state is AuthStateGetUsers && state.users.isEmpty) {
            return const Center(
              child: Text('Empty !', style: TextStyle(color: Colors.black)),
            );
          }
          if (state is AuthStateGetUsers) {
            final users = state.users;
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => BlocProvider.value(
                            value: sl<AuthBloc>(),
                            child: const AdminAddUserScreen(),
                          ),
                        ),
                      );
                    },
                    child: const Text(
                        'Add User'), // -> send to another modalsheet using authbloc or bloc for cameras..
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: users.length,
                    itemBuilder: (context, index) {
                      final user = users[index];
                      return UserCard(user: user);
                    },
                  ),
                ),
              ],
            );
          } else if (state is AuthStateError) {
            return Center(
              child: Text('Error: ${state.message}'),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}

class UserCard extends StatefulWidget {
  final LocalUser user;

  const UserCard({super.key, required this.user});
  @override
  _UserCardState createState() => _UserCardState();
}

class _UserCardState extends State<UserCard> {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text('User Name: ${widget.user.fullName}'),
        subtitle: Text('User Email: ${widget.user.email}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => BlocProvider.value(
                      value: sl<AuthBloc>(),
                      child: EditUserAdmin(user: widget.user),
                    ),
                  ),
                );
              },
            ),
            // IconButton(
            //   icon: const Icon(Icons.delete),
            //   onPressed: () {
            //     //Firetry().deleteItem(categoryTitle, categoryItem.id);
            //   },
            // ),
          ],
        ),
      ),
    );
  }
}
