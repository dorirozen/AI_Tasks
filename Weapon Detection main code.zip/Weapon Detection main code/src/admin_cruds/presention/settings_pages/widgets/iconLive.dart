import 'package:flutter/material.dart';

Widget buildLiveStatusIcon(bool isLive) {
  debugPrint("$isLive");
  return Container(
    padding: const EdgeInsets.all(8),
    child: Icon(
      isLive ? Icons.online_prediction : Icons.offline_bolt,
      color: isLive ? Colors.green : Colors.red,
      size: 50,
    ),
  );
}
