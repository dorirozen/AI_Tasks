// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
//
// import '../../../../core/common/widgets/gradient_background.dart';
// import '../../../../core/enums/update_settings.dart';
// import '../../../../core/utils/core_utils.dart';
// import '../blocs/settings_bloc/settings_bloc.dart';
// import '../blocs/settings_bloc/settings_event.dart';
// import '../blocs/settings_bloc/settings_state.dart';
//
// class SettingsPage extends StatefulWidget {
//   const SettingsPage({Key? key}) : super(key: key);
//
//   @override
//   State<SettingsPage> createState() => _SettingsPageState();
// }
//
// class _SettingsPageState extends State<SettingsPage> {
//   final thresHoldController = TextEditingController();
//   final isLiveController = TextEditingController();
//
//   bool _listenersAdded = false;
//   late void Function() refreshThresHold;
//   late void Function() refreshIsLive;
//
//   bool isThresHoldChanged = false;
//   bool isLiveChanged = false;
//
//   @override
//   void initState() {
//     super.initState();
//     context.read<SettingsBloc>().add(SettingEventGet());
//   }
//
//   @override
//   void dispose() {
//     if (_listenersAdded) {
//       thresHoldController.removeListener(refreshThresHold);
//       isLiveController.removeListener(refreshIsLive);
//     }
//     thresHoldController.dispose();
//     isLiveController.dispose();
//     super.dispose();
//   }
//
//   void _addListenersIfNeeded(Function refresh) {
//     if (!_listenersAdded) {
//       refreshThresHold = () {
//         refresh(() {
//           final currentState = context.read<SettingsBloc>().state;
//           if (currentState is SettingsStateGet) {
//             isThresHoldChanged = thresHoldController.text !=
//                 currentState.settingCrud.threshHold.toString();
//           }
//         });
//       };
//       refreshIsLive = () {
//         refresh(() {
//           final currentState = context.read<SettingsBloc>().state;
//           if (currentState is SettingsStateGet) {
//             isLiveChanged = isLiveController.text.toLowerCase() !=
//                 currentState.settingCrud.isLive.toString();
//           }
//         });
//       };
//
//       thresHoldController.addListener(refreshThresHold);
//       isLiveController.addListener(refreshIsLive);
//       _listenersAdded = true;
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return BlocConsumer<SettingsBloc, SettingsState>(
//       listener: (context, state) {
//         if (state is SettingsStateLoading) {
//           // Show loading indicator if needed
//         }
//         if (state is SettingsStateUpdated) {
//           Navigator.pop(context);
//           CoreUtils.showSnackBar(context, 'Settings updated successfully');
//         } else if (state is SettingsStateError) {
//           CoreUtils.showSnackBar(context, state.message);
//         } else if (state is SettingsStateGet) {
//           // Populate the text fields with the loaded settings
//           thresHoldController.text = state.settingCrud.threshHold.toString();
//           isLiveController.text = state.settingCrud.isLive.toString();
//         }
//       },
//       builder: (context, state) {
//         return Scaffold(
//           extendBodyBehindAppBar: true,
//           appBar: AppBar(
//             leading: const BackButton(),
//             actions: [
//               TextButton(
//                 onPressed: () {
//                   if (!isThresHoldChanged && !isLiveChanged)
//                     Navigator.pop(context);
//                   final bloc = context.read<SettingsBloc>();
//                   if (isThresHoldChanged) {
//                     bloc.add(
//                       SettingEventEdit(
//                         action: UpdateSettingsAction.threshHold,
//                         settingsData:
//                             double.parse(thresHoldController.text.trim()),
//                       ),
//                     );
//                   }
//                   if (isLiveChanged) {
//                     bloc.add(
//                       SettingEventEdit(
//                         action: UpdateSettingsAction.isLive,
//                         settingsData:
//                             isLiveController.text.toLowerCase() == 'true',
//                       ),
//                     );
//                   }
//                 },
//                 child: state is SettingsStateLoading
//                     ? const Center(
//                         child: CircularProgressIndicator(),
//                       )
//                     : StatefulBuilder(builder: (_, refresh) {
//                         _addListenersIfNeeded(refresh);
//
//                         return Text(
//                           'Done',
//                           style: TextStyle(
//                             fontWeight: FontWeight.w500,
//                             fontSize: 16,
//                             color: (!isThresHoldChanged && !isLiveChanged)
//                                 ? Colors.grey
//                                 : Colors.blueAccent,
//                           ),
//                         );
//                       }),
//               ),
//             ],
//           ),
//           body: GradientBackGround(
//             image:
//                 'assets/images/background.png', // Adjust the image path as needed
//             darkenImage: true,
//             child: ListView(
//               padding: const EdgeInsets.symmetric(horizontal: 20),
//               children: [
//                 const SizedBox(height: 180),
//                 TextField(
//                   controller: thresHoldController,
//                   decoration: InputDecoration(
//                     labelText: 'Threshold',
//                   ),
//                   keyboardType: TextInputType.number,
//                 ),
//                 TextField(
//                   controller: isLiveController,
//                   decoration: InputDecoration(
//                     labelText: 'Is Live',
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/core/common/app/providers/settings_provider.dart';

import '../../../../core/common/widgets/gradient_background.dart';
import '../../../../core/enums/update_settings.dart';
import '../../../../core/utils/core_utils.dart';
import '../blocs/settings_bloc/settings_bloc.dart';
import '../blocs/settings_bloc/settings_event.dart';
import '../blocs/settings_bloc/settings_state.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final thresHoldController = TextEditingController();
  final isLiveController = TextEditingController();

  bool isThresHoldChanged = false;
  bool isLiveChanged = false;

  @override
  void initState() {
    super.initState();
    context.read<SettingsBloc>().add(const SettingEventGet());
    thresHoldController.addListener(_onThresHoldChanged);
    isLiveController.addListener(_onIsLiveChanged);
  }

  @override
  void dispose() {
    thresHoldController.removeListener(_onThresHoldChanged);
    isLiveController.removeListener(_onIsLiveChanged);
    thresHoldController.dispose();
    isLiveController.dispose();

    super.dispose();
  }

  void _onThresHoldChanged() {
    if (mounted) {
      setState(() {
        final currentState = context.read<SettingsBloc>().state;
        if (currentState is SettingsStateGet) {
          isThresHoldChanged = thresHoldController.text !=
              currentState.settingCrud.threshHold.toString();
        }
      });
    }
  }

  void _onIsLiveChanged() {
    if (mounted) {
      setState(() {
        final currentState = context.read<SettingsBloc>().state;
        if (currentState is SettingsStateGet) {
          isLiveChanged = isLiveController.text.toLowerCase() !=
              currentState.settingCrud.isLive.toString();
        }
        //context.read<SettingsProvider>().setIsLive(isLiveController.text.toLowerCase() as bool);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SettingsBloc, SettingsState>(
      listener: (context, state) {
        if (state is SettingsStateUpdated) {
          Navigator.pop(context);
          CoreUtils.showSnackBar(context, 'Settings updated successfully');
        } else if (state is SettingsStateError) {
          CoreUtils.showSnackBar(context, state.message);
        } else if (state is SettingsStateGet) {
          thresHoldController.text = state.settingCrud.threshHold.toString();
          isLiveController.text = state.settingCrud.isLive.toString();
        }
      },
      builder: (context, state) {
        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            leading: const BackButton(),
            actions: [
              TextButton(
                onPressed: () {
                  if (!isThresHoldChanged && !isLiveChanged) {
                    Navigator.pop(context);
                  } else {
                    final bloc = context.read<SettingsBloc>();
                    if (isThresHoldChanged) {
                      bloc.add(
                        SettingEventEdit(
                          action: UpdateSettingsAction.threshHold,
                          settingsData:
                              double.parse(thresHoldController.text.trim()),
                        ),
                      );
                    }
                    if (isLiveChanged) {
                      context
                          .read<SettingsProvider>()
                          .setIsLive(isLiveController.text.toLowerCase());
                      debugPrint("isLive Changed from settings UI");
                      bloc.add(
                        SettingEventEdit(
                          action: UpdateSettingsAction.isLive,
                          settingsData:
                              isLiveController.text.toLowerCase() == 'true',
                        ),
                      );
                    }
                  }
                },
                child: state is SettingsStateLoading
                    ? const Center(child: CircularProgressIndicator())
                    : Text(
                        'Done',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: (!isThresHoldChanged && !isLiveChanged)
                              ? Colors.grey
                              : Colors.blueAccent,
                        ),
                      ),
              ),
            ],
          ),
          body: GradientBackGround(
            image: 'assets/images/background.png',
            darkenImage: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                const SizedBox(height: 180),
                TextField(
                  controller: thresHoldController,
                  style: const TextStyle(
                      color: Colors.white), // This sets the input text color
                  decoration: InputDecoration(
                    labelText: 'Threshold',
                    labelStyle: const TextStyle(
                        color: Colors.white), // This sets the label text color
                    hintText: 'Enter threshold value',
                    hintStyle: TextStyle(
                        color: Colors.white
                            .withOpacity(0.7)), // This sets the hint text color
                    fillColor: Colors.white.withOpacity(
                        0.1), // This sets the background color of the TextField
                    filled: true,
                    border: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: Colors.white.withOpacity(0.5)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: isLiveController,
                  style: const TextStyle(
                      color: Colors.white), // This sets the input text color
                  decoration: InputDecoration(
                    labelText: 'Is Live',
                    labelStyle: const TextStyle(
                        color: Colors.white), // This sets the label text color
                    hintText: 'Change Is Live value',
                    hintStyle: TextStyle(
                        color: Colors.white
                            .withOpacity(0.7)), // This sets the hint text color
                    fillColor: Colors.white.withOpacity(
                        0.1), // This sets the background color of the TextField
                    filled: true,
                    border: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: Colors.white.withOpacity(0.5)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  keyboardType: TextInputType.number,
                ),
                // TextField(
                //   controller: thresHoldController,
                //   decoration: InputDecoration(
                //     labelText: 'Threshold',
                //   ),
                //   keyboardType: TextInputType.number,
                // ),
                // TextField(
                //   controller: isLiveController,
                //   decoration: InputDecoration(labelText: 'Is Live'),
                // ),
              ],
            ),
          ),
        );
      },
    );
  }
}
