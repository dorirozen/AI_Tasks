import 'package:equatable/equatable.dart';
import '../../../../../core/enums/update_settings.dart';

abstract class SettingsEvent extends Equatable {
  const SettingsEvent();
  @override
  List<Object?> get props => [];
}

class SettingEventGet extends SettingsEvent {
  const SettingEventGet();
}

class SettingEventEdit extends SettingsEvent {
  const SettingEventEdit({required this.settingsData, required this.action});
  final dynamic settingsData;
  final UpdateSettingsAction action;
  @override
  List<Object?> get props => [settingsData, action];
}
