import 'package:equatable/equatable.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/setting.dart';

abstract class SettingsState extends Equatable {
  const SettingsState();
  @override
  List<Object?> get props => [];
}

//basic helpers
class SettingsStateInitial extends SettingsState {
  const SettingsStateInitial();
}

class SettingsStateLoading extends SettingsState {
  const SettingsStateLoading();
}

class SettingsStateError extends SettingsState {
  const SettingsStateError(this.message);
  final String message;
  @override
  List<String> get props => [message];
}

// basic return finished states

class SettingsStateUpdated extends SettingsState {
  const SettingsStateUpdated();
  @override
  List<Object> get props => [];
}

class SettingsStateGet extends SettingsState {
  const SettingsStateGet(this.settingCrud);
  final SettingCrud settingCrud;
  @override
  List<Object> get props => [settingCrud];
}
