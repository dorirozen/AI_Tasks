import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:guardian_view/src/admin_cruds/presention/blocs/settings_bloc/settings_event.dart';
import 'package:guardian_view/src/admin_cruds/presention/blocs/settings_bloc/settings_state.dart';

import '../../../domain/usecases/settings_crud_us/edit_settings_US.dart';
import '../../../domain/usecases/settings_crud_us/get_settings_us.dart';

class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  SettingsBloc({
    required EditSettingsUS editSettingsUS,
    required GetSettingsUS getSettingsUS,
  })  : _editSettingsUS = editSettingsUS,
        _getSettingsUS = getSettingsUS,
        super(const SettingsStateInitial()) {
    on<SettingsEvent>((event, emit) {
      emit(const SettingsStateLoading());
    });
    on<SettingEventGet>(_activateSettingsEventGet);
    on<SettingEventEdit>(_activateSettingsEventEdit);
  }
  final EditSettingsUS _editSettingsUS;
  final GetSettingsUS _getSettingsUS;

  FutureOr<void> _activateSettingsEventEdit(
      SettingEventEdit event, Emitter<SettingsState> emit) async {
    final res = await _editSettingsUS(
        SettingsParams(action: event.action, settingsData: event.settingsData));
    res.fold(
      (l) => emit(SettingsStateError(l.errorMessage)),
      (_) => emit(const SettingsStateUpdated()),
    );
  }

  FutureOr<void> _activateSettingsEventGet(
      SettingEventGet event, Emitter<SettingsState> emit) async {
    final res = await _getSettingsUS();
    res.fold((l) => emit(SettingsStateError(l.errorMessage)), (r) {
      emit(SettingsStateGet(r));

      // emit(AuthStateGetUsers(r));
    });
  }
}
