// import 'dart:async';
//
// import 'package:flutter_bloc/flutter_bloc.dart';
//
// import '../../../domain/entities/camera.dart';
// import '../../../domain/usecases/cameras_crud_us/add_camera_us.dart';
// import '../../../domain/usecases/cameras_crud_us/edit_camera_US.dart';
// import '../../../domain/usecases/cameras_crud_us/get_cameras_US.dart';
// import 'camera_event.dart';
// import 'camera_state.dart';
//
// class CameraBloc extends Bloc<CameraEvent, CameraState> {
//   CameraBloc({
//     required AddCameraUS addCameraUS,
//     required EditCameraUS editCameraUS,
//     required GetCamerasUS getCamerasUS,
//   })  : _addCameraUS = addCameraUS,
//         _editCameraUS = editCameraUS,
//         _getCamerasUS = getCamerasUS,
//         super(const CameraStateInitial()) {
//     on<CameraEvent>((event, emit) {
//       emit(const CameraStateLoading());
//     });
//     on<CameraEventAddCamera>(_activateCameraEventAddCamera);
//     on<CameraEventEdit>(_activateCameraEventEdit);
//     on<CameraEventGetCameras>(_activateCameraEventGetCameras);
//   }
//   final AddCameraUS _addCameraUS;
//   final EditCameraUS _editCameraUS;
//   final GetCamerasUS _getCamerasUS;
//
//   FutureOr<void> _activateCameraEventAddCamera(
//       CameraEventAddCamera event, Emitter<CameraState> emit) async {
//     final res = await _addCameraUS(CameraCrud(
//         cameraId: event.cameraId,
//         locationName: event.locationName,
//         landscape: event.landscape,
//         latitude: event.latitude));
//     res.fold(
//       (l) => emit(CameraStateError(l.errorMessage)),
//       (_) => emit(const CameraStateAdded()),
//     );
//   }
//
//   FutureOr<void> _activateCameraEventEdit(
//       EditCameraUS event, Emitter<CameraState> emit) async {
//     final res = await _editCameraUS(UpdateCameraParamsCrud());
//     res.fold(
//       (l) => emit(CameraStateError(l.errorMessage)),
//       (_) => emit(const CameraStateEditedCamera()),
//     );
//   }
//
//   FutureOr<void> _activateCameraEventGetCameras(
//       CameraEventGetCameras event, Emitter<CameraState> emit) async {
//     final res = await _getCamerasUS();
//     res.fold((l) => emit(CameraStateError(l.errorMessage)), (r) {
//       final filteredUsers = r.toList();
//       emit(CameraStateGetCameras(filteredUsers));
//       // emit(AuthStateGetUsers(r));
//     });
//   }
// }
