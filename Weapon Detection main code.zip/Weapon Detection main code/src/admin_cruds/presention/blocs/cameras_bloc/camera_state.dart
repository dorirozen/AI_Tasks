// import 'package:equatable/equatable.dart';
// import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';
//
// abstract class CameraState extends Equatable {
//   const CameraState();
//   @override
//   List<Object?> get props => [];
// }
//
// //basic helpers
// class CameraStateInitial extends CameraState {
//   const CameraStateInitial();
// }
//
// class CameraStateLoading extends CameraState {
//   const CameraStateLoading();
// }
//
// class CameraStateError extends CameraState {
//   const CameraStateError(this.message);
//   final String message;
//   @override
//   List<String> get props => [message];
// }
//
// class CameraStateAdded extends CameraState {
//   const CameraStateAdded();
// }
//
// class CameraStateEditedCamera extends CameraState {
//   const CameraStateEditedCamera();
// }
//
// class CameraStateGetCameras extends CameraState {
//   const CameraStateGetCameras(this.cameras);
//   final List<CameraCrud> cameras;
//   @override
//   List<Object> get props => [cameras];
// }
