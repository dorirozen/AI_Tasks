// import 'package:equatable/equatable.dart';
//
// import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';
//
// import '../../../../../core/enums/update_camera.dart';
//
// abstract class CameraEvent extends Equatable {
//   const CameraEvent();
//   @override
//   List<Object?> get props => [];
// }
//
// class CameraEventAddCamera extends CameraEvent {
//   const CameraEventAddCamera({
//     required this.cameraId,
//     required this.locationName,
//     required this.latitude,
//     required this.landscape,
//   });
//   final String cameraId;
//   final String locationName;
//   final double latitude;
//   final double landscape;
//
//   @override
//   List<Object?> get props => [cameraId, locationName];
// }
//
// class CameraEventGetCameras extends CameraEvent {
//   final CameraCrud currentUser;
//   const CameraEventGetCameras({required this.currentUser});
// }
//
// class CameraEventEdit extends CameraEvent {
//   CameraEventEdit(
//       {required this.cameraData,
//       required this.action,
//       required this.cameraCrud});
//
//   final dynamic cameraData;
//   final UpdateCameraAction action;
//   final CameraCrud cameraCrud;
//   @override
//   List<Object?> get props => [cameraData, action, cameraCrud];
// }
