import 'package:equatable/equatable.dart';

class SettingCrud extends Equatable {
  final double threshHold;
  final bool isLive;
  const SettingCrud({required this.isLive, required this.threshHold});

  @override
  List<Object?> get props => [threshHold, isLive];

  const SettingCrud.empty() : this(isLive: false, threshHold: 0.0);

  @override
  String toString() {
    return 'SettingCrud{threshHold: $threshHold, radiusForAlerts: $isLive}';
  }
}
