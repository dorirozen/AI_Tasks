import 'package:equatable/equatable.dart';

class CameraCrud extends Equatable {
  final String cameraId;
  final String locationName;
  final double latitude;
  final double landscape;
  const CameraCrud(
      {required this.latitude,
      required this.landscape,
      required this.cameraId,
      required this.locationName});
  const CameraCrud.empty()
      : this(landscape: 0.0, latitude: 0.0, cameraId: '', locationName: '');

  @override
  List<Object?> get props => [cameraId, locationName, latitude, landscape];

  @override
  String toString() {
    return 'CameraCrud{cameraId: $cameraId, locationName: $locationName, latitude: $latitude, landscape: $landscape}';
  }
}
