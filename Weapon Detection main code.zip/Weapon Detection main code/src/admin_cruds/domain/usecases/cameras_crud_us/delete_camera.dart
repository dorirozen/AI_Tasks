import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/repos/camera_crud_repo/camera_crud_repo.dart';

class DeleteCameraUS extends UsecaseWithParams<void, String> {
  const DeleteCameraUS(this._cameraCrudRepository);
  final CameraCrudRepository _cameraCrudRepository;
  @override
  ResultFuture<void> call(String params) =>
      _cameraCrudRepository.deleteCamera(params);
}
