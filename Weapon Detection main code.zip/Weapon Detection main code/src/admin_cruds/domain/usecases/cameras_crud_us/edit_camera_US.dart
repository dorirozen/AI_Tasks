import 'package:equatable/equatable.dart';
import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/enums/update_camera.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/repos/camera_crud_repo/camera_crud_repo.dart';

class EditCameraUS extends UsecaseWithParams<void, UpdateCameraParamsCrud> {
  final CameraCrudRepository _cameraCrudRepository;
  const EditCameraUS(this._cameraCrudRepository);

  @override
  ResultFuture<void> call(UpdateCameraParamsCrud params) =>
      _cameraCrudRepository.editCamera(
          action: params.action, cameraData: params.cameraData);
}

class UpdateCameraParamsCrud extends Equatable {
  const UpdateCameraParamsCrud(
      {required this.action, required this.cameraData});
  final UpdateCameraAction action;
  final dynamic cameraData;

  const UpdateCameraParamsCrud.empty()
      : action = UpdateCameraAction.locationName,
        cameraData = '';

  @override
  List<Object?> get props => [action, cameraData];
}
