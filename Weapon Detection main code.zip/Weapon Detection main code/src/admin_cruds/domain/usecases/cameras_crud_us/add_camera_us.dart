import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';
import 'package:guardian_view/src/admin_cruds/domain/repos/camera_crud_repo/camera_crud_repo.dart';

class AddCameraUS extends UsecaseWithParams<void, CameraCrud> {
  final CameraCrudRepository _cameraCrudRepository;
  const AddCameraUS(this._cameraCrudRepository);

  @override
  ResultFuture<void> call(CameraCrud params) =>
      _cameraCrudRepository.addCamera(params);
}
