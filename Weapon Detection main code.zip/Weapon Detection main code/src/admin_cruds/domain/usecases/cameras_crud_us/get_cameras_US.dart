import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';
import 'package:guardian_view/src/admin_cruds/domain/repos/camera_crud_repo/camera_crud_repo.dart';

class GetCamerasUS extends UsecaseWithOutParams<List<CameraCrud>> {
  final CameraCrudRepository _cameraCrudRepository;
  const GetCamerasUS(this._cameraCrudRepository);
  @override
  ResultFuture<List<CameraCrud>> call() => _cameraCrudRepository.getCameras();
}
