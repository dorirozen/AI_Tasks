import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/setting.dart';
import 'package:guardian_view/src/admin_cruds/domain/repos/settings_crud_repo/setting_crud_repo.dart';

class GetSettingsUS extends UsecaseWithOutParams<SettingCrud> {
  final SettingCrudRepository _settingCrudRepository;
  const GetSettingsUS(this._settingCrudRepository);

  @override
  ResultFuture<SettingCrud> call() => _settingCrudRepository.getSettings();
}
