import 'package:equatable/equatable.dart';
import 'package:guardian_view/core/common/usecases/usecase.dart';
import 'package:guardian_view/core/enums/update_settings.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/repos/settings_crud_repo/setting_crud_repo.dart';

class EditSettingsUS extends UsecaseWithParams<void, SettingsParams> {
  final SettingCrudRepository _settingCrudRepository;
  const EditSettingsUS(this._settingCrudRepository);

  @override
  ResultFuture<void> call(SettingsParams params) => _settingCrudRepository
      .editSetting(action: params.action, settingsData: params.settingsData);
}

class SettingsParams extends Equatable {
  final UpdateSettingsAction action;
  final dynamic settingsData;

  const SettingsParams({
    required this.action,
    required this.settingsData,
  });

  const SettingsParams.empty()
      : settingsData = '',
        action = UpdateSettingsAction.threshHold;

  @override
  List<Object?> get props => [action, settingsData];
}
