import 'package:guardian_view/core/enums/update_camera.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';

abstract class CameraCrudRepository {
  ResultFuture<List<CameraCrud>> getCameras();

  ResultFuture<void> addCamera(CameraCrud camera);

  ResultFuture<void> editCamera({
    required UpdateCameraAction action,
    dynamic cameraData,
  });
  ResultFuture<void> deleteCamera(String cameraId);
}
