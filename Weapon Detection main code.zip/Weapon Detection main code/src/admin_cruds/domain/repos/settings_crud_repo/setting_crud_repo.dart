import 'package:guardian_view/core/enums/update_settings.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/setting.dart';

abstract class SettingCrudRepository {
  ResultFuture<SettingCrud> getSettings();
  ResultFuture<void> editSetting(
      {required UpdateSettingsAction action, dynamic settingsData});
}
