import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:guardian_view/core/enums/update_settings.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/setting.dart';

abstract class CrudSettingDataSource {
  const CrudSettingDataSource();

  Future<void> editSettings({
    required UpdateSettingsAction action,
    required settingsData,
  });

  Future<SettingCrud> getSetting();
}

///ready

class CrudSettingDataSourceImpl implements CrudSettingDataSource {
  const CrudSettingDataSourceImpl({
    required FirebaseFirestore cloudStoreClient,
  }) : _cloudStoreClient = cloudStoreClient;
  final FirebaseFirestore _cloudStoreClient;
  @override
  Future<void> editSettings({
    required UpdateSettingsAction action,
    required dynamic settingsData,
  }) async {
    try {
      final settingsDoc =
          _cloudStoreClient.collection('settings').doc('FNuqsKfLHVsCtZlicI66');

      switch (action) {
        case UpdateSettingsAction.isLive:
          if (settingsData is bool) {
            await settingsDoc.update({
              'isLive': settingsData,
            });
          } else {
            throw ArgumentError(
                'settingsData must be a bool for isLive action');
          }
          break;
        case UpdateSettingsAction.threshHold:
          if (settingsData is double) {
            await settingsDoc.update({
              'threshHold': settingsData,
            });
          } else {
            throw ArgumentError(
                'settingsData must be a double for threshHold action');
          }
          break;
      }
    } catch (e) {
      debugPrint('Error editing settings: $e');
      rethrow;
    }
  }

  @override
  Future<SettingCrud> getSetting() async {
    try {
      final docSnapshot = await _cloudStoreClient
          .collection('settings')
          .doc('FNuqsKfLHVsCtZlicI66')
          .get();
      if (docSnapshot.exists) {
        final data = docSnapshot.data()!;
        debugPrint(
            "the current threshold is !! -- ${data['threshHold'] ?? 0.0}--");
        return SettingCrud(
          isLive: data['isLive'] ?? false,
          threshHold: (data['threshHold'] ?? 0.0).toDouble(),
        );
      } else {
        throw Exception('Settings document does not exist');
      }
    } catch (e) {
      debugPrint('Error getting setting: $e');
      rethrow;
    }
  }
}
