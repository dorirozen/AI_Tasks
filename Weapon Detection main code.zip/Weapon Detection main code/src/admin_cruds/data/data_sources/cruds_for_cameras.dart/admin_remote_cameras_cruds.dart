import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:guardian_view/core/enums/update_camera.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';

abstract class CrudCameraDataSource {
  const CrudCameraDataSource();

  Future<void> addCamera({required CameraCrud camera});

  Future<List<CameraCrud>> getCameras();

  Future<void> editCamera(
      {required UpdateCameraAction action,
      required cameraData,
      required String cameraId});

  Future<void> deleteCamera({required String cameraId});
}

///ready
class CrudCameraDataSourceImpl implements CrudCameraDataSource {
  const CrudCameraDataSourceImpl({
    required FirebaseFirestore cloudStoreClient,
  }) : _cloudStoreClient = cloudStoreClient;
  final FirebaseFirestore _cloudStoreClient;

  @override
  Future<void> addCamera({required CameraCrud camera}) {
    // TODO: implement addCamera
    throw UnimplementedError();
  }

  @override
  Future<void> deleteCamera({required String cameraId}) {
    // TODO: implement deleteCamera
    throw UnimplementedError();
  }

  @override
  Future<void> editCamera(
      {required UpdateCameraAction action,
      required cameraData,
      required String cameraId}) {
    // TODO: implement editCamera
    throw UnimplementedError();
  }

  @override
  Future<List<CameraCrud>> getCameras() {
    // TODO: implement getCameras
    throw UnimplementedError();
  }
}
