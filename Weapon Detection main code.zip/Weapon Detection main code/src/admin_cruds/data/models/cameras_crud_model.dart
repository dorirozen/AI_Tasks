import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';

class CamerasCrudModel extends CameraCrud {
  const CamerasCrudModel(
      {required super.latitude,
      required super.landscape,
      required super.cameraId,
      required super.locationName});
  const CamerasCrudModel.empty()
      : this(landscape: 0.0, latitude: 0.0, cameraId: '', locationName: '');
  CamerasCrudModel copyWith({
    String? cameraId,
    String? locationName,
    double? latitude,
    double? landscape,
  }) {
    return CamerasCrudModel(
      cameraId: cameraId ?? this.cameraId,
      locationName: locationName ?? this.locationName,
      latitude: latitude ?? this.latitude,
      landscape: landscape ?? this.landscape,
    );
  }

  DataMap toMap() {
    return {
      'cameraId': cameraId,
      'locationName': locationName,
      'latitude': latitude,
      'landscape': landscape,
    };
  }

  CamerasCrudModel.fromMap(DataMap map)
      : super(
          landscape: map['landscape'] as double,
          locationName: map['locationName'] as String,
          latitude: map['latitude'] as double,
          cameraId: map['cameraId'] as String,
        );
}
