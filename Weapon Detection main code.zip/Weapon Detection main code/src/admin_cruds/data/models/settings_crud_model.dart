import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/setting.dart';

class SettingsCrudModel extends SettingCrud {
  const SettingsCrudModel({required super.threshHold, required super.isLive});
  const SettingsCrudModel.empty()
      : this(
          threshHold: 0.0,
          isLive: false,
        );
  SettingsCrudModel copyWith({
    double? threshHold,
    double? isLive,
  }) {
    return SettingsCrudModel(
      isLive: this.isLive,
      threshHold: threshHold ?? this.threshHold,
    );
  }

  DataMap toMap() {
    return {
      'threshHold': threshHold,
      'isLive': isLive,
    };
  }

  SettingsCrudModel.fromMap(DataMap map)
      : super(
            isLive: map['isLive'] as bool,
            threshHold: map['threshHold'] as double);
}
