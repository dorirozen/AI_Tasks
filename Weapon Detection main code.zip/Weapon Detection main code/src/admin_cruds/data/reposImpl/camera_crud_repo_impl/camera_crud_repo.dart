// import 'package:dartz/dartz.dart';
// import 'package:guardian_view/core/enums/update_camera.dart';
// import 'package:guardian_view/core/error/exceptions.dart';
// import 'package:guardian_view/core/error/failures.dart';
// import 'package:guardian_view/core/typedefs/typedef.dart';
// import 'package:guardian_view/src/admin_cruds/data/data_sources/cruds_for_cameras.dart/admin_remote_cameras_cruds.dart';
// import 'package:guardian_view/src/admin_cruds/domain/entities/camera.dart';
// import 'package:guardian_view/src/admin_cruds/domain/repos/camera_crud_repo/camera_crud_repo.dart';
//
// class CameraCrudRepositoryImpl implements CameraCrudRepository {
//   final CrudCameraDataSource _crudCameraDataSource;
//   const CameraCrudRepositoryImpl(this._crudCameraDataSource);
//
//   @override
//   ResultFuture<void> addCamera(CameraCrud camera) async {
//     try {
//       await _crudCameraDataSource.addCamera(camera: camera);
//       return const Right(null);
//     } on ServerException catch (e) {
//       return Left(ServerFailure(message: e.message, statusCode: e.statusCode));
//     }
//   }
//
//   @override
//   ResultFuture<List<CameraCrud>> getCameras() async {
//     try {
//       final res = await _crudCameraDataSource.getCameras();
//       return Right(res);
//     } on ServerException catch (e) {
//       return Left(ServerFailure(message: e.message, statusCode: e.statusCode));
//     }
//   }
//
//   @override
//   ResultFuture<void> editCamera(
//       {required UpdateCameraAction action,
//       cameraData,
//       required String cameraId}) async {
//     try {
//       await _crudCameraDataSource.editCamera(
//           action: action, cameraData: cameraData, cameraId: cameraId);
//       return const Right(null);
//     } on ServerException catch (e) {
//       return Left(ServerFailure(message: e.message, statusCode: e.statusCode));
//     }
//   }
//
//   @override
//   ResultFuture<void> deleteCamera(String cameraId) async {
//     try {
//       await _crudCameraDataSource.deleteCamera(cameraId: cameraId);
//       return const Right(null);
//     } on ServerException catch (e) {
//       return Left(ServerFailure(message: e.message, statusCode: e.statusCode));
//     }
//   }
// }
