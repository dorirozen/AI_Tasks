import 'package:dartz/dartz.dart';
import 'package:guardian_view/core/enums/update_settings.dart';
import 'package:guardian_view/core/error/exceptions.dart';
import 'package:guardian_view/core/error/failures.dart';
import 'package:guardian_view/core/typedefs/typedef.dart';
import 'package:guardian_view/src/admin_cruds/data/data_sources/cruds_for_settings.dart/admin_remote_settings_cruds.dart';
import 'package:guardian_view/src/admin_cruds/domain/entities/setting.dart';
import 'package:guardian_view/src/admin_cruds/domain/repos/settings_crud_repo/setting_crud_repo.dart';

class SettingCrudRepositoryImpl implements SettingCrudRepository {
  final CrudSettingDataSource _crudSettingDataSource;
  const SettingCrudRepositoryImpl(this._crudSettingDataSource);
  @override
  ResultFuture<void> editSetting({
    required UpdateSettingsAction action,
    settingsData,
  }) async {
    try {
      await _crudSettingDataSource.editSettings(
          action: action, settingsData: settingsData);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure(message: e.message, statusCode: e.statusCode));
    }
  }

  @override
  ResultFuture<SettingCrud> getSettings() async {
    try {
      final res = await _crudSettingDataSource.getSetting();
      return Right(res);
    } on ServerException catch (e) {
      return Left(ServerFailure(message: e.message, statusCode: e.statusCode));
    }
  }
}
